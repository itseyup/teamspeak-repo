insert into custom_fields
( server_id,
  client_id,
  ident,
  value)
VALUES 
( :server_id:,
  :client_id:,
  :ident:,
  :value:);
