
using System.IO;
using UnrealBuildTool;

public class TeamSpeak_SDK : ModuleRules
{
	public TeamSpeak_SDK(TargetInfo Target)
	{
		PublicDependencyModuleNames.AddRange(new string[] { "Core", "CoreUObject", "Engine", "InputCore" });

		PrivateDependencyModuleNames.AddRange(new string[] {  });

		// Uncomment if you are using Slate UI
		// PrivateDependencyModuleNames.AddRange(new string[] { "Slate", "SlateCore" });
		
		// Uncomment if you are using online features
		// PrivateDependencyModuleNames.Add("OnlineSubsystem");
		// if ((Target.Platform == UnrealTargetPlatform.Win32) || (Target.Platform == UnrealTargetPlatform.Win64))
		// {
		//		if (UEBuildConfiguration.bCompileSteamOSS == true)
		//		{
		//			DynamicallyLoadedModuleNames.Add("OnlineSubsystemSteam");
		//		}
		// }
        LoadTeamSpeakLib(Target);
	}

    private string ModulePath
    {
        get { return Path.GetDirectoryName(RulesCompiler.GetModuleFilename(this.GetType().Name)); }
    }

    private string ThirdPartyPath
    {
        get { return Path.GetFullPath(Path.Combine(ModulePath, "../../ThirdParty/")); }
    }    
 
    public bool LoadTeamSpeakLib(TargetInfo Target) {
        bool isLibrarySupported = false;
 
        if(Target.Platform == UnrealTargetPlatform.Win64) {
            isLibrarySupported = true;
            string LibrariesPath = Path.Combine(ThirdPartyPath, "TeamSpeak_lib", "Libraries");
            PublicAdditionalLibraries.Add(Path.Combine(LibrariesPath, "ts3client_win64.lib"));
        } else if (Target.Platform == UnrealTargetPlatform.Win32) {
            isLibrarySupported = true;
            string LibrariesPath = Path.Combine(ThirdPartyPath, "TeamSpeak_lib", "Libraries");
            PublicAdditionalLibraries.Add(Path.Combine(LibrariesPath, "ts3client_win32.lib"));
        }
         
        if(isLibrarySupported) {
            PublicIncludePaths.Add(Path.Combine(ThirdPartyPath, "TeamSpeak_lib", "Includes"));
        }
 
        Definitions.Add(string.Format( "WITH_BOBS_MAGIC_BINDING={0}", isLibrarySupported ? 1 : 0 ) );
 
        return isLibrarySupported;
    }
}
