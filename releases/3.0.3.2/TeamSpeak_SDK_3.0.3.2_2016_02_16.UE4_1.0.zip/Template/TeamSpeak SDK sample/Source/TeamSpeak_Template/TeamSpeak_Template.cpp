// Copyright 1998-2015 Epic Games, Inc. All Rights Reserved.

#include "TeamSpeak_Template.h"


IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, TeamSpeak_Template, "TeamSpeak_Template" );

DEFINE_LOG_CATEGORY(LogTeamSpeak_Template)
 