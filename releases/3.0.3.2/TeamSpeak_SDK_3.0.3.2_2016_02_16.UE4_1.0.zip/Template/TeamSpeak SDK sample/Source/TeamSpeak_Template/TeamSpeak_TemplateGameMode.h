// Copyright 1998-2015 Epic Games, Inc. All Rights Reserved.
#pragma once
#include "GameFramework/GameMode.h"
#include "TeamSpeakFunctionLibrary.h"
#include "TeamSpeak_Manager.h"
#include "TeamSpeak_TemplateGameMode.generated.h"

UCLASS(minimalapi)
class ATeamSpeak_TemplateGameMode : public AGameMode
{
	GENERATED_BODY()

public:
	ATeamSpeak_TemplateGameMode(const FObjectInitializer& ObjectInitializer);
	TeamSpeak_Manager* ts_manager;
};



