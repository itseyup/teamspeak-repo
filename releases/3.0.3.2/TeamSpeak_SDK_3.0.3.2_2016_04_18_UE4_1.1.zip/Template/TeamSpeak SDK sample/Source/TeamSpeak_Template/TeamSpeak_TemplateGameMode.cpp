// Copyright 1998-2015 Epic Games, Inc. All Rights Reserved.

#include "TeamSpeak_Template.h"
#include "TeamSpeak_TemplateGameMode.h"
#include "TeamSpeak_TemplatePlayerController.h"
#include "TeamSpeak_TemplateCharacter.h"

ATeamSpeak_TemplateGameMode::ATeamSpeak_TemplateGameMode(const FObjectInitializer& ObjectInitializer) : Super(ObjectInitializer)
{
	// use our custom PlayerController class
	PlayerControllerClass = ATeamSpeak_TemplatePlayerController::StaticClass();

	// set default pawn class to our Blueprinted character
	static ConstructorHelpers::FClassFinder<APawn> PlayerPawnBPClass(TEXT("/Game/TopDown/Blueprints/TopDownCharacter"));
	if (PlayerPawnBPClass.Class != NULL)
	{
		DefaultPawnClass = PlayerPawnBPClass.Class;
	}
	ts_manager = new TeamSpeak_Manager;
}