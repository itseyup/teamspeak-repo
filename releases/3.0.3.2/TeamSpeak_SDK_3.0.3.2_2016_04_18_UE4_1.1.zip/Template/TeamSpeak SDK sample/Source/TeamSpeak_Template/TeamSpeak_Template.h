// Copyright 1998-2015 Epic Games, Inc. All Rights Reserved.

#ifndef __TEAMSPEAK_TEMPLATE_H__
#define __TEAMSPEAK_TEMPLATE_H__

#include "EngineMinimal.h"

DECLARE_LOG_CATEGORY_EXTERN(LogTeamSpeak_Template, Log, All);


#endif
