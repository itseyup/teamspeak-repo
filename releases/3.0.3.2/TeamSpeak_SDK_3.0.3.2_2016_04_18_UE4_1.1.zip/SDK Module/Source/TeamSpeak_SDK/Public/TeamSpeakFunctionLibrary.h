#pragma once
#include "TeamSpeak_Manager.h"
#include "../ThirdParty/TeamSpeak_lib/Includes/teamspeak/public_errors.h"

#include "Kismet/BlueprintFunctionLibrary.h"
#include "TeamSpeakFunctionLibrary.generated.h"

UENUM(BlueprintType)
enum class ETeamSpeak_TalkStatus : uint8 {
	STATUS_NOT_TALKING = 0,
	STATUS_TALKING = 1,
	STATUS_TALKING_WHILE_DISABLED = 2,
};

UENUM(BlueprintType)
enum class  ETeamSpeak_CodecType : uint8 {
	CODEC_SPEEX_NARROWBAND = 0,   //mono,   16bit,  8kHz, bitrate dependent on the quality setting
	CODEC_SPEEX_WIDEBAND,         //mono,   16bit, 16kHz, bitrate dependent on the quality setting
	CODEC_SPEEX_ULTRAWIDEBAND,    //mono,   16bit, 32kHz, bitrate dependent on the quality setting
	CODEC_CELT_MONO,              //mono,   16bit, 48kHz, bitrate dependent on the quality setting
	CODEC_OPUS_VOICE,             //mono,   16bit, 48khz, bitrate dependent on the quality setting, optimized for voice
	CODEC_OPUS_MUSIC,             //stereo, 16bit, 48khz, bitrate dependent on the quality setting, optimized for music
};

UENUM(BlueprintType)
enum class  ETeamSpeak_CodecEncryptionMode : uint8 {
	CODEC_ENCRYPTION_PER_CHANNEL = 0,
	CODEC_ENCRYPTION_FORCED_OFF,
	CODEC_ENCRYPTION_FORCED_ON,
};

UENUM(BlueprintType)
enum class ETeamSpeak_TextMessageTargetMode : uint8 {
	TextMessageTarget_CLIENT = 1,
	TextMessageTarget_CHANNEL,
	TextMessageTarget_SERVER,
	TextMessageTarget_MAX
};

UENUM(BlueprintType)
enum class ETeamSpeak_MuteInputStatus : uint8 {
	MUTEINPUT_NONE = 0,
	MUTEINPUT_MUTED,
};

UENUM(BlueprintType)
enum class ETeamSpeak_MuteOutputStatus : uint8 {
	MUTEOUTPUT_NONE = 0,
	MUTEOUTPUT_MUTED,
};

UENUM(BlueprintType)
enum class ETeamSpeak_HardwareInputStatus : uint8 {
	HARDWAREINPUT_DISABLED = 0,
	HARDWAREINPUT_ENABLED,
};

UENUM(BlueprintType)
enum class ETeamSpeak_HardwareOutputStatus : uint8 {
	HARDWAREOUTPUT_DISABLED = 0,
	HARDWAREOUTPUT_ENABLED,
};

UENUM(BlueprintType)
enum class ETeamSpeak_InputDeactivationStatus : uint8 {
	INPUT_ACTIVE = 0,
	INPUT_DEACTIVATED = 1,
};

UENUM(BlueprintType)
enum class ETeamSpeak_ReasonIdentifier : uint8 {
	REASON_NONE = 0,  //no reason data
	REASON_MOVED = 1,  //{SectionInvoker}
	REASON_SUBSCRIPTION = 2,  //no reason data
	REASON_LOST_CONNECTION = 3,  //reasonmsg=reason
	REASON_KICK_CHANNEL = 4,  //{SectionInvoker} reasonmsg=reason               //{SectionInvoker} is only added server->client
	REASON_KICK_SERVER = 5,  //{SectionInvoker} reasonmsg=reason               //{SectionInvoker} is only added server->client
	REASON_KICK_SERVER_BAN = 6,  //{SectionInvoker} reasonmsg=reason bantime=time  //{SectionInvoker} is only added server->client
	REASON_SERVERSTOP = 7,  //reasonmsg=reason
	REASON_CLIENTDISCONNECT = 8,  //reasonmsg=reason
	REASON_CHANNELUPDATE = 9,  //no reason data
	REASON_CHANNELEDIT = 10, //{SectionInvoker}
	REASON_CLIENTDISCONNECT_SERVER_SHUTDOWN = 11,  //reasonmsg=reason
};

UENUM(BlueprintType)
enum class ETeamSpeak_ChannelProperties : uint8 {
	CHANNEL_NAME = 0,                       //Available for all channels that are "in view", always up-to-date
	CHANNEL_TOPIC,                          //Available for all channels that are "in view", always up-to-date
	CHANNEL_DESCRIPTION,                    //Must be requested (=> requestChannelDescription)
	CHANNEL_PASSWORD,                       //not available client side
	CHANNEL_CODEC,                          //Available for all channels that are "in view", always up-to-date
	CHANNEL_CODEC_QUALITY,                  //Available for all channels that are "in view", always up-to-date
	CHANNEL_MAXCLIENTS,                     //Available for all channels that are "in view", always up-to-date
	CHANNEL_MAXFAMILYCLIENTS,               //Available for all channels that are "in view", always up-to-date
	CHANNEL_ORDER,                          //Available for all channels that are "in view", always up-to-date
	CHANNEL_FLAG_PERMANENT,                 //Available for all channels that are "in view", always up-to-date
	CHANNEL_FLAG_SEMI_PERMANENT,            //Available for all channels that are "in view", always up-to-date
	CHANNEL_FLAG_DEFAULT,                   //Available for all channels that are "in view", always up-to-date
	CHANNEL_FLAG_PASSWORD,                  //Available for all channels that are "in view", always up-to-date
	CHANNEL_CODEC_LATENCY_FACTOR,           //Available for all channels that are "in view", always up-to-date
	CHANNEL_CODEC_IS_UNENCRYPTED,           //Available for all channels that are "in view", always up-to-date
	CHANNEL_SECURITY_SALT,                  //Not available client side, not used in teamspeak, only SDK. Sets the options+salt for security hash.
	CHANNEL_DELETE_DELAY,                   //How many seconds to wait before deleting this channel
	CHANNEL_ENDMARKER,
};

UENUM(BlueprintType)
enum class ETeamSpeak_ClientProperties : uint8 {
	CLIENT_UNIQUE_IDENTIFIER = 0,           //automatically up-to-date for any client "in view", can be used to identify this particular client installation
	CLIENT_NICKNAME,                        //automatically up-to-date for any client "in view"
	CLIENT_VERSION,                         //for other clients than ourself, this needs to be requested (=> requestClientVariables)
	CLIENT_PLATFORM,                        //for other clients than ourself, this needs to be requested (=> requestClientVariables)
	CLIENT_FLAG_TALKING,                    //automatically up-to-date for any client that can be heard (in room / whisper)
	CLIENT_INPUT_MUTED,                     //automatically up-to-date for any client "in view", this clients microphone mute status
	CLIENT_OUTPUT_MUTED,                    //automatically up-to-date for any client "in view", this clients headphones/speakers/mic combined mute status
	CLIENT_OUTPUTONLY_MUTED,                //automatically up-to-date for any client "in view", this clients headphones/speakers only mute status
	CLIENT_INPUT_HARDWARE,                  //automatically up-to-date for any client "in view", this clients microphone hardware status (is the capture device opened?)
	CLIENT_OUTPUT_HARDWARE,                 //automatically up-to-date for any client "in view", this clients headphone/speakers hardware status (is the playback device opened?)
	CLIENT_INPUT_DEACTIVATED,               //only usable for ourself, not propagated to the network
	CLIENT_IDLE_TIME,                       //internal use
	CLIENT_DEFAULT_CHANNEL,                 //only usable for ourself, the default channel we used to connect on our last connection attempt
	CLIENT_DEFAULT_CHANNEL_PASSWORD,        //internal use
	CLIENT_SERVER_PASSWORD,                 //internal use
	CLIENT_META_DATA,                       //automatically up-to-date for any client "in view", not used by TeamSpeak, free storage for sdk users
	CLIENT_IS_MUTED,                        //only make sense on the client side locally, "1" if this client is currently muted by us, "0" if he is not
	CLIENT_IS_RECORDING,                    //automatically up-to-date for any client "in view"
	CLIENT_VOLUME_MODIFICATOR,              //internal use
	CLIENT_VERSION_SIGN,					//sign
	CLIENT_SECURITY_HASH,                   //SDK use, not used by teamspeak. Hash is provided by an outside source. A channel will use the security salt + other client data to calculate a hash, which must be the same as the one provided here.
	CLIENT_ENDMARKER,
};

UENUM(BlueprintType)
enum class ETeamSpeak_VirtualServerProperties : uint8 {
	VIRTUALSERVER_UNIQUE_IDENTIFIER = 0,             //available when connected, can be used to identify this particular server installation
	VIRTUALSERVER_NAME,                              //available and always up-to-date when connected
	VIRTUALSERVER_WELCOMEMESSAGE,                    //available when connected,  (=> requestServerVariables)
	VIRTUALSERVER_PLATFORM,                          //available when connected
	VIRTUALSERVER_VERSION,                           //available when connected
	VIRTUALSERVER_MAXCLIENTS,                        //only available on request (=> requestServerVariables), stores the maximum number of clients that may currently join the server
	VIRTUALSERVER_PASSWORD,                          //not available to clients, the server password
	VIRTUALSERVER_CLIENTS_ONLINE,                    //only available on request (=> requestServerVariables),
	VIRTUALSERVER_CHANNELS_ONLINE,                   //only available on request (=> requestServerVariables),
	VIRTUALSERVER_CREATED,                           //available when connected, stores the time when the server was created
	VIRTUALSERVER_UPTIME,                            //only available on request (=> requestServerVariables), the time since the server was started
	VIRTUALSERVER_CODEC_ENCRYPTION_MODE,             //available and always up-to-date when connected
	VIRTUALSERVER_ENDMARKER,
};

UENUM(BlueprintType)
enum class ETeamSpeak_LogTypes : uint8 {
	LogType_NONE = 0x0000,
	LogType_FILE = 0x0001,
	LogType_CONSOLE = 0x0002,
	LogType_USERLOGGING = 0x0004,
	LogType_NO_NETLOGGING = 0x0008,
	LogType_DATABASE = 0x0010,
};

UENUM(BlueprintType)
enum class ETeamSpeak_LogLevel : uint8 {
	LogLevel_CRITICAL = 0, //these messages stop the program
	LogLevel_ERROR,        //everything that is really bad, but not so bad we need to shut down
	LogLevel_WARNING,      //everything that *might* be bad
	LogLevel_DEBUG,        //output that might help find a problem
	LogLevel_INFO,         //informational output, like "starting database version x.y.z"
	LogLevel_DEVEL         //developer only output (will not be displayed in release mode)
};

UENUM(BlueprintType)
enum class ETeamSpeak_GroupWhisperType : uint8 {
	GROUPWHISPERTYPE_SERVERGROUP = 0,
	GROUPWHISPERTYPE_CHANNELGROUP = 1,
	GROUPWHISPERTYPE_CHANNELCOMMANDER = 2,
	GROUPWHISPERTYPE_ALLCLIENTS = 3,
	GROUPWHISPERTYPE_ENDMARKER,
};

UENUM(BlueprintType)
enum class ETeamSpeak_GroupWhisperTargetMode : uint8 {
	GROUPWHISPERTARGETMODE_ALL = 0,
	GROUPWHISPERTARGETMODE_CURRENTCHANNEL = 1,
	GROUPWHISPERTARGETMODE_PARENTCHANNEL = 2,
	GROUPWHISPERTARGETMODE_ALLPARENTCHANNELS = 3,
	GROUPWHISPERTARGETMODE_CHANNELFAMILY = 4,
	GROUPWHISPERTARGETMODE_ANCESTORCHANNELFAMILY = 5,
	GROUPWHISPERTARGETMODE_SUBCHANNELS = 6,
	GROUPWHISPERTARGETMODE_ENDMARKER,
};

UENUM(BlueprintType)
enum class ETeamSpeak_MonoSoundDestination : uint8 {
	MONO_SOUND_DESTINATION_ALL = 0, /* Send mono sound to all available speakers */
	MONO_SOUND_DESTINATION_FRONT_CENTER = 1, /* Send mono sound to front center speaker if available */
	MONO_SOUND_DESTINATION_FRONT_LEFT_AND_RIGHT = 2  /* Send mono sound to front left/right speakers if available */
};

UENUM(BlueprintType)
enum class ETeamSpeak_SecuritySaltOptions : uint8 {
	SECURITY_SALT_CHECK_NICKNAME = 1, /* put nickname into security hash */
	SECURITY_SALT_CHECK_META_DATA = 2  /* put (game)meta data into security hash */
};

UENUM(BlueprintType)
enum class ETeamSpeak_ClientCommand : uint8 {
	CLIENT_COMMAND_requestConnectionInfo = 0,
	CLIENT_COMMAND_requestClientMove = 1,
	CLIENT_COMMAND_requestXXMuteClients = 2,
	CLIENT_COMMAND_requestClientKickFromXXX = 3,
	CLIENT_COMMAND_flushChannelCreation = 4,
	CLIENT_COMMAND_flushChannelUpdates = 5,
	CLIENT_COMMAND_requestChannelMove = 6,
	CLIENT_COMMAND_requestChannelDelete = 7,
	CLIENT_COMMAND_requestChannelDescription = 8,
	CLIENT_COMMAND_requestChannelXXSubscribeXXX = 9,
	CLIENT_COMMAND_requestServerConnectionInfo = 10,
	CLIENT_COMMAND_requestSendXXXTextMsg = 11,
	CLIENT_COMMAND_ENDMARKER = 12
};

UENUM(BlueprintType)
enum class ETeamSpeak_ACLType : uint8 {
	ACL_NONE = 0,
	ACL_WHITE_LIST = 1,
	ACL_BLACK_LIST = 2
};

USTRUCT(BlueprintType)
struct FTeamSpeak_2dArray {
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TArray<FString> value;

	FTeamSpeak_2dArray(TArray<FString> v) {
		value = v;
	}

    FTeamSpeak_2dArray() {};
};

template<typename T>
struct FTeamSpeak_valueHandler {
	 T value;

	uint32 errorCode;

	T getValue() {
		return value;
	}
	uint32 getErrorCode() {
		return errorCode;
	}

	FTeamSpeak_valueHandler(T val, uint32 err) {
		errorCode = err;
		value = val;
	}
protected:
    FTeamSpeak_valueHandler() = delete;
};

UCLASS()
class TEAMSPEAK_SDK_API UTeamSpeakFunctionLibrary : public UBlueprintFunctionLibrary {
	GENERATED_UCLASS_BODY()

	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Statics")
	static UTeamSpeakFunctionLibrary* getUTeamSpeakFunctionLibrary();
	
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Debug")
	static void printMessageDebug(FString str);

	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Debug")
	static FString getSoundBackendDir_Editor();

	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Init/Destroy")
	static void TeamSpeak_initClientLib(ETeamSpeak_LogTypes usedLogTypes, FString logFileFolder, FString resourcesFolder, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Init/Destroy")
	static void TeamSpeak_destroyClientLib(int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Init/Destroy")
	static FString TeamSpeak_getClientLibVersion(int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Init/Destroy")
	static int32 TeamSpeak_getClientLibVersionNumber(int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Init/Destroy")
	static int32 TeamSpeak_spawnNewServerConnectionHandler(int32 port, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Init/Destroy")
	static void TeamSpeak_destroyServerConnectionHandler(int32 serverConnectionHandlerID, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Init/Destroy")
	static FString TeamSpeak_createIdentity(int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Init/Destroy")
	static FString TeamSpeak_identityStringToUniqueIdentifier(FString identityString, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Sound")
	static TArray<FTeamSpeak_2dArray> TeamSpeak_getPlaybackDeviceList(FString modeID, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Sound")
	static TArray<FTeamSpeak_2dArray> TeamSpeak_getCaptureDeviceList(FString modeID, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Sound")
	static TArray<FString> TeamSpeak_getPlaybackModeList(int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Sound")
	static TArray<FString> TeamSpeak_getCaptureModeList(int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Sound")
	static TArray<FString> TeamSpeak_getDefaultPlaybackDevice(FString modeID, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Sound")
	static TArray<FString> TeamSpeak_getDefaultCaptureDevice(FString modeID, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Sound")
	static FString TeamSpeak_getDefaultPlayBackMode(int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Sound")
	static FString TeamSpeak_getDefaultCaptureMode(int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Sound")
	static void TeamSpeak_openPlaybackDevice(int32 serverConnectionHandlerID, FString modeID, FString playbackDevice, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Sound")
	static void TeamSpeak_openCaptureDevice(int32 serverConnectionHandlerID, FString modeID, FString captureDevice, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Sound")
	static FString TeamSpeak_getCurrentPlaybackDeviceName(int32 serverConnectionHandlerID, int32 &error, int32 &isDefault);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Sound")
	static FString TeamSpeak_getCurrentPlayBackMode(int32 serverConnectionHandlerID, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Sound")
	static FString TeamSpeak_getCurrentCaptureDeviceName(int32 serverConnectionHandlerID, int32 &error, int32 &isDefault);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Sound")
	static FString TeamSpeak_getCurrentCaptureMode(int32 serverConnectionHandlerID, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Sound")
	static void TeamSpeak_initiateGracefulPlaybackShutdown(int32 serverConnectionHandlerID, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Sound")
	static void TeamSpeak_closePlaybackDevice(int32 serverConnectionHandlerID, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Sound")
	static void TeamSpeak_closeCaptureDevice(int32 serverConnectionHandlerID, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Sound")
	static void TeamSpeak_activateCaptureDevice(int32 serverConnectionHandlerID, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Sound")
	static void TeamSpeak_playWaveFile(int32 serverConnectionHandlerID, FString path, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Sound")
	static void TeamSpeak_playWaveFileHandle(int32 serverConnectionHandlerID, FString path, int32 loop, int32 waveHandle, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Sound")
	static void TeamSpeak_pauseWaveFileHandle(int32 serverConnectionHandlerID, int32 waveHandle, int32 pause, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Sound")
	static void TeamSpeak_closeWaveFileHandle(int32 serverConnectionHandlerID, int32 waveHandle, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Sound")
	static void TeamSpeak_registerCustomDevice(FString deviceID, FString deviceDisplayName, int32 capFrequency, int32 capChannels, int32 playFrequency, int32 playChannels, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Sound")
	static void TeamSpeak_unregisterCustomDevice(FString deviceID, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Sound")
	static void TeamSpeak_processCustomCaptureData(FString deviceName, TArray<int32> buffer, int32 samples, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Sound")
	static void TeamSpeak_acquireCustomPlaybackData(FString deviceName, TArray<int32> buffer, int32 samples, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Sound")
	static void TeamSpeak_setLocalTestMode(int32 serverConnectionHandlerID, int32 status, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Sound")
	static void TeamSpeak_startVoiceRecording(int32 serverConnectionHandlerID, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Sound")
	static void TeamSpeak_stopVoiceRecording(int32 serverConnectionHandlerID, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Whisper")
	static void TeamSpeak_allowWhispersFrom(int32 serverConnectionHandlerID, int32 clID, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Whisper")
	static void TeamSpeak_removeFromAllowedWhispersFrom(int32 serverConnectionHandlerID, int32 clID, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Sound")
	static void TeamSpeak_systemset3DListenerAttributes(int32 serverConnectionHandlerID, FVector position, FVector forward, FVector up, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Sound")
	static void TeamSpeak_set3DWaveAttributes(int32 serverConnectionHandlerID, int32 waveHandle, FVector position, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Sound")
	static void TeamSpeak_systemset3DSettings(int32 serverConnectionHandlerID, float distanceFactor, float rolloffScale, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Sound")
	static void TeamSpeak_channelset3DAttributes(int32 serverConnectionHandlerID, int32 clientID, FVector position, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Sound")
	static float TeamSpeak_getPreProcessorInfoValueFloat(int32 serverConnectionHandlerID, FString ident, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Sound")
	static FString TeamSpeak_getPreProcessorConfigValue(int32 serverConnectionHandlerID, FString ident, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Sound")
	static void TeamSpeak_setPreProcessorConfigValue(int32 serverConnectionHandlerID, FString ident, FString value, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Sound")
	static FString TeamSpeak_getEncodeConfigValu(int32 serverConnectionHandlerID, FString ident, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Sound")
	static float TeamSpeak_getPlaybackConfigValueAsFloat(int32 serverConnectionHandlerID, FString ident, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Sound")
	static void TeamSpeak_setPlaybackConfigValue(int32 serverConnectionHandlerID, FString ident, FString value, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Sound")
	static void TeamSpeak_setClientVolumeModifier(int32 serverConnectionHandlerID, int32 clientID, float value, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Log")
	static void TeamSpeak_logMessage(FString logMessage, int32 severity, FString channel, int32 logID, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Log")
	static void TeamSpeak_setLogVerbosity(int32 logVerbosity, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|ErrorHandling")
	static FString TeamSpeak_getErrorMessage(int32 errorCode, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Connection")
	static void TeamSpeak_startConnection(int32 serverConnectionHandlerID, FString identity, FString ip, int32 port, FString nickname, TArray<FString> defaultChannelArray, FString defaultChannelPassword, FString serverPassword, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Connection")
	static void TeamSpeak_stopConnection(int32 serverConnectionHandlerID, FString quitMessage, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Client")
	static void TeamSpeak_requestClientMove(int32 serverConnectionHandlerID, int32 clientID, int32 newChannelID, FString password, FString returnCode, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Client")
	static void TeamSpeak_requestClientVariables(int32 serverConnectionHandlerID, int32 clientID, FString returnCode, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Client")
	static void TeamSpeak_requestClientKickFromChannel(int32 serverConnectionHandlerID, int32 clientID, FString kickReason, FString returnCode, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Client")
	static void TeamSpeak_requestClientKickFromServer(int32 serverConnectionHandlerID, int32 clientID, FString kickReason, FString returnCode, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Channel")
	static void TeamSpeak_requestChannelDelete(int32 serverConnectionHandlerID, int32 channelID, int32 force, FString returnCode, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Channel")
	static void TeamSpeak_requestChannelMove(int32 serverConnectionHandlerID, int32 channelID, int32 newChannelParentID, int32 newChannelOrder, FString returnCode, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Message")
	static void TeamSpeak_requestSendPrivateTextMsg(int32 serverConnectionHandlerID, FString message, int32 targetClientID, FString returnCode, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Message")
	static void TeamSpeak_requestSendChannelTextMsg(int32 serverConnectionHandlerID, FString message, int32 targetChannelID, FString returnCode, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Message")
	static void TeamSpeak_requestSendServerTextMsg(int32 serverConnectionHandlerID, FString message, FString returnCode, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Connection")
	static void TeamSpeak_requestConnectionInfo(int32 serverConnectionHandlerID, int32 clientID, FString returnCode, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Whisper")
	static void TeamSpeak_requestClientSetWhisperList(int32 serverConnectionHandlerID, int32 clientID, TArray<int32> targetChannelIDArray, TArray<int32> targetClientIDArray, FString returnCode, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Subscription")
	static void TeamSpeak_requestChannelSubscribe(int32 serverConnectionHandlerID, TArray<int32> channelIDArray, FString returnCode, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Subscription")
	static void TeamSpeak_requestChannelSubscribeAll(int32 serverConnectionHandlerID, FString returnCode, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Subscription")
	static void TeamSpeak_requestChannelUnsubscribe(int32 serverConnectionHandlerID, TArray<int32> channelIDArray, FString returnCode, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Subscription")
	static void TeamSpeak_requestChannelUnsubscribeAll(int32 serverConnectionHandlerID, FString returnCode, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Channel")
	static void TeamSpeak_requestChannelDescription(int32 serverConnectionHandlerID, int32 channelID, FString returnCode, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Client")
	static void TeamSpeak_requestMuteClients(int32 serverConnectionHandlerID, TArray<int32> clientIDArray, FString returnCode, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Client")
	static void TeamSpeak_requestUnmuteClients(int32 serverConnectionHandlerID, TArray<int32> clientIDArray, FString returnCode, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Client")
	static void TeamSpeak_requestClientIDs(int32 serverConnectionHandlerID, FString clientUniqueIdentifier, FString returnCode, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Provisioning")
	static int32 TeamSpeak_requestSlotsFromProvisioningServer(FString ip, int32 port, FString serverPassword, int32 slots, FString identity, FString region, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Provisioning")
	static void TeamSpeak_cancelRequestSlotsFromProvisioningServer(int32 requestHandle, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Provisioning")
	static void TeamSpeak_startConnectionWithProvisioningKey(int32 serverConnectionHandlerID, FString identity, FString nickname, FString connectionKey, FString clientMetaData, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Client")
	static int32 TeamSpeak_getClientID(int32 serverConnectionHandlerID, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Connection")
	static int32 TeamSpeak_getConnectionStatus(int32 serverConnectionHandlerID, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Connection")
	static void TeamSpeak_cleanUpConnectionInfo(int32 serverConnectionHandlerID, int32 clientID, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Connection")
	static void TeamSpeak_requestServerConnectionInfo(int32 serverConnectionHandlerID, FString returnCode, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Client")
	static int32 TeamSpeak_getClientSelfVariableAsint32(int32 serverConnectionHandlerID, ETeamSpeak_ClientProperties flag, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Client")
	static FString TeamSpeak_getClientSelfVariableAsString(int32 serverConnectionHandlerID, ETeamSpeak_ClientProperties flag, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Client")
	static void TeamSpeak_setClientSelfVariableAsint32(int32 serverConnectionHandlerID, ETeamSpeak_ClientProperties flag, int32 value, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Client")
	static void TeamSpeak_setClientSelfVariableAsString(int32 serverConnectionHandlerID, ETeamSpeak_ClientProperties flag, FString value, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Client")
	static void TeamSpeak_flushClientSelfUpdates(int32 serverConnectionHandlerID, FString returnCode, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Client")
	static int32 TeamSpeak_getClientVariableAsInt(int32 serverConnectionHandlerID, int32 clientID, ETeamSpeak_ClientProperties flag, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Client")
	static int32 TeamSpeak_getClientVariableAsUint64(int32 serverConnectionHandlerID, int32 clientID, ETeamSpeak_ClientProperties flag, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Client")
	static FString TeamSpeak_getClientVariableAsString(int32 serverConnectionHandlerID, int32 clientID, ETeamSpeak_ClientProperties flag, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Client")
	static TArray<int32> TeamSpeak_getClientList(int32 serverConnectionHandlerID, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Channel")
	static int32 TeamSpeak_getChannelOfClient(int32 serverConnectionHandlerID, int32 clientID, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Channel")
	static int32 TeamSpeak_getChannelVariableAsInt(int32 serverConnectionHandlerID, int32 channelID, ETeamSpeak_ChannelProperties flag, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Channel")
	static int32 TeamSpeak_getChannelVariableAsUint64(int32 serverConnectionHandlerID, int32 channelID, ETeamSpeak_ChannelProperties flag, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Channel")
	static FString TeamSpeak_getChannelVariableAsString(int32 serverConnectionHandlerID, int32 channelID, ETeamSpeak_ChannelProperties flag, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Channel")
	static int32 TeamSpeak_getChannelIDFromChannelNames(int32 serverConnectionHandlerID, TArray<FString> channelNameArray, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Channel")
	static void TeamSpeak_setChannelVariableAsInt(int32 serverConnectionHandlerID, int32 channelID, ETeamSpeak_ChannelProperties flag, int32 value, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Channel")
	static void TeamSpeak_setChannelVariableAsUint64(int32 serverConnectionHandlerID, int32 channelID, ETeamSpeak_ChannelProperties flag, int32 value, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Channel")
	static void TeamSpeak_setChannelVariableAsString(int32 serverConnectionHandlerID, int32 channelID, ETeamSpeak_ChannelProperties flag, FString value, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Channel")
	static void TeamSpeak_flushChannelUpdates(int32 serverConnectionHandlerID, int32 channelID, FString returnCode, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Channel")
	static void TeamSpeak_flushChannelCreation(int32 serverConnectionHandlerID, int32 channelParentID, FString returnCode, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Channel")
	static TArray<int32> TeamSpeak_getChannelList(int32 serverConnectionHandlerID, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Channel")
	static TArray<int32> TeamSpeak_getChannelClientList(int32 serverConnectionHandlerID, int32 channelID, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Channel")
	static int32 TeamSpeak_getParentChannelOfChannel(int32 serverConnectionHandlerID, int32 channelID, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Channel")
	static int32 TeamSpeak_getChannelEmptySecs(int32 serverConnectionHandlerID, int32 channelID, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Init/Destroy")
	static TArray<int32> TeamSpeak_getServerConnectionHandlerList(int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Connection")
	static int32 TeamSpeak_getServerVariableAsUint64(int32 serverConnectionHandlerID, ETeamSpeak_VirtualServerProperties flag, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Connection")
	static int32 TeamSpeak_getServerVariableAsInt(int32 serverConnectionHandlerID, ETeamSpeak_VirtualServerProperties flag, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Connection")
	static FString TeamSpeak_getServerVariableAsString(int32 serverConnectionHandlerID, ETeamSpeak_VirtualServerProperties flag, int32 &error);
	UFUNCTION(BlueprintCallable, Category = "TeamSpeak|Function|Connection")
	static void TeamSpeak_requestServerVariables(int32 serverConnectionHandlerID, int32 &error);

	DECLARE_DYNAMIC_MULTICAST_DELEGATE_ThreeParams(FTeamSpeakOnConnectStatusChangeEvent, int32, serverconnectionHandlerID, int32, newStatus, int32, errorNumber);
	UPROPERTY(BlueprintAssignable, Category = "TeamSpeak|Callbacks|Connection")
	FTeamSpeakOnConnectStatusChangeEvent onConnectStatusChangeEvent;

	DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FTeamSpeakOnServerProtocolVersionEvent, int32, serverconnectionHandlerID, int32, protocolVersion);
	UPROPERTY(BlueprintAssignable, Category = "TeamSpeak|Callbacks|Server")
	FTeamSpeakOnServerProtocolVersionEvent onServerProtocolVersionEvent;
	
	DECLARE_DYNAMIC_MULTICAST_DELEGATE_ThreeParams(FTeamSpeakOnNewChannelEvent, int32, serverconnectionHandlerID, int32, channelID, int32, channelParentID);
	UPROPERTY(BlueprintAssignable, Category = "TeamSpeak|Callbacks|Channel")
	FTeamSpeakOnNewChannelEvent onNewChannelEvent;
	
	DECLARE_DYNAMIC_MULTICAST_DELEGATE_SixParams(FTeamSpeakOnNewChannelCreatedEvent, int32, serverconnectionHandlerID, int32, channelID, int32, channelParentID, uint32, invokerID, FString, invokerName, FString, invokerUniqueIdentifier);
	UPROPERTY(BlueprintAssignable, Category = "TeamSpeak|Callbacks|Channel")
	FTeamSpeakOnNewChannelCreatedEvent onNewChannelCreatedEvent;
	
	DECLARE_DYNAMIC_MULTICAST_DELEGATE_FiveParams(FTeamSpeakOnDelChannelEvent, int32, serverconnectionHandlerID, int32, channelID, uint32, invokerID, FString, invokerName, FString, invokerUniqueIdentifier);
	UPROPERTY(BlueprintAssignable, Category = "TeamSpeak|Callbacks|Channel")
	FTeamSpeakOnDelChannelEvent onDelChannelEvent;
	
	DECLARE_DYNAMIC_MULTICAST_DELEGATE_SixParams(FTeamSpeakOnChannelMoveEvent, int32, serverconnectionHandlerID, int32, channelID, int32, newChannelParentID, uint32, invokerID, FString, invokerName, FString, invokerUniqueIdentifier);
	UPROPERTY(BlueprintAssignable, Category = "TeamSpeak|Callbacks|Channel")
	FTeamSpeakOnChannelMoveEvent onChannelMoveEvent;
	
	DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FTeamSpeakOnUpdateChannelEvent, int32, serverconnectionHandlerID, int32, channelID);
	UPROPERTY(BlueprintAssignable, Category = "TeamSpeak|Callbacks|Channel")
	FTeamSpeakOnUpdateChannelEvent onUpdateChannelEvent;
	
	DECLARE_DYNAMIC_MULTICAST_DELEGATE_FiveParams(FTeamSpeakOnUpdateChannelEditedEvent, int32, serverconnectionHandlerID, int32, channelID, uint32,  invokerID, FString, invokerName, FString, invokerUniqueIdentifier);
	UPROPERTY(BlueprintAssignable, Category = "TeamSpeak|Callbacks|Channel")
	FTeamSpeakOnUpdateChannelEditedEvent onUpdateChannelEditedEvent;
	
	DECLARE_DYNAMIC_MULTICAST_DELEGATE_FiveParams(FTeamSpeakOnUpdateClientEvent, uint32, serverConnectionHalderID, uint32, clientID, uint32, invokerID, FString, invokerName, FString, invokerUniqueIndentivier);
	UPROPERTY(BlueprintAssignable, Category = "TeamSpeak|Callbacks|Client")
	FTeamSpeakOnUpdateClientEvent onUpdateClientEvent;
	
	DECLARE_DYNAMIC_MULTICAST_DELEGATE_SixParams(FTeamSpeakOnClientMoveEvent, int32, serverconnectionHandlerID, uint32, clientID, int32, oldChannelID, int32, newChannelID, uint32, visibility, FString, moveMessage);
	UPROPERTY(BlueprintAssignable, Category = "TeamSpeak|Callbacks|Client")
	FTeamSpeakOnClientMoveEvent onClientMoveEvent;
	
	DECLARE_DYNAMIC_MULTICAST_DELEGATE_FiveParams(FTeamSpeakOnClientMoveSubscriptionEvent, int32, serverconnectionHandlerID, uint32, clientID, int32, oldChannelID, int32, newChannelID, uint32, visibility);
	UPROPERTY(BlueprintAssignable, Category = "TeamSpeak|Callbacks|Client")
	FTeamSpeakOnClientMoveSubscriptionEvent onClientMoveSubscriptionEvent;
	
	DECLARE_DYNAMIC_MULTICAST_DELEGATE_SixParams(FTeamSpeakOnClientMoveTimeoutEvent, int32, serverconnectionHandlerID, uint32, clientID, int32, oldChannelID, int32, newChannelID, uint32, visibility, FString, moveMessage);
	UPROPERTY(BlueprintAssignable, Category = "TeamSpeak|Callbacks|Client")
	FTeamSpeakOnClientMoveTimeoutEvent onClientMoveTimeoutEvent;
	
	DECLARE_DYNAMIC_MULTICAST_DELEGATE_EightParams(FTeamSpeakOnClientMoveMovedEvent, int32, serverconnectionHandlerID, uint32, clientID, int32, oldChannelID, int32, newChannelID, uint32, visibility, uint32, moverID, TArray<FString>, moverNameAndUniqueIdentifier, FString, moveMessage);
	UPROPERTY(BlueprintAssignable, Category = "TeamSpeak|Callbacks|Client")
	FTeamSpeakOnClientMoveMovedEvent onClientMoveMovedEvent;

	DECLARE_DYNAMIC_MULTICAST_DELEGATE_EightParams(FTeamSpeakOnClientKickFromChannelEvent, int32, serverconnectionHandlerID, uint32, clientID, int32, oldChannelID, int32, newChannelID, uint32, visibility, uint32, kickerID, TArray<FString>, moverNameAndUniqueIdentifier, FString, kickMessage);
	UPROPERTY(BlueprintAssignable, Category = "TeamSpeak|Callbacks|Client")
	FTeamSpeakOnClientKickFromChannelEvent onClientKickFromChannelEvent;

	DECLARE_DYNAMIC_MULTICAST_DELEGATE_EightParams(FTeamSpeakOnClientKickFromServerEvent, int32, serverconnectionHandlerID, uint32, clientID, int32, oldChannelID, int32, newChannelID, uint32, visibility, uint32, kickerID, TArray<FString>, moverNameAndUniqueIdentifier, FString, kickMessage);
	UPROPERTY(BlueprintAssignable, Category = "TeamSpeak|Callbacks|Client")
	FTeamSpeakOnClientKickFromServerEvent onClientKickFromServerEvent;
	
	DECLARE_DYNAMIC_MULTICAST_DELEGATE_FourParams(FTeamSpeakOnClientIDsEvent, int32, serverconnectionHandlerID, FString, uniqueClientIdentifier, uint32, clientID, FString, clientName);
	UPROPERTY(BlueprintAssignable, Category = "TeamSpeak|Callbacks|Client")
	FTeamSpeakOnClientIDsEvent onClientIDsEvent;
	
	DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FTeamSpeakOnClientIDsFinishedEvent, int32, serverconnectionHandlerID);
	UPROPERTY(BlueprintAssignable, Category = "TeamSpeak|Callbacks|Client")
	FTeamSpeakOnClientIDsFinishedEvent onClientIDsFinishedEvent;
	
	DECLARE_DYNAMIC_MULTICAST_DELEGATE_FourParams(FTeamSpeakOnServerEditedEvent, int32, serverconnectionHandlerID, uint32, editerID, FString, editerName, FString, editerUniqueIdentifier);
	UPROPERTY(BlueprintAssignable, Category = "TeamSpeak|Callbacks|Server")
	FTeamSpeakOnServerEditedEvent onServerEditedEvent;
	
	DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FTeamSpeakOnServerUpdatedEvent, int32, serverconnectionHandlerID);
	UPROPERTY(BlueprintAssignable, Category = "TeamSpeak|Callbacks|Server")
	FTeamSpeakOnServerUpdatedEvent onServerUpdatedEvent;
	
	DECLARE_DYNAMIC_MULTICAST_DELEGATE_FiveParams(FTeamSpeakOnServerErrorEvent, int32, serverConnectionHandlerID, FString, errorMessage, int32, error, FString, returnCode, FString, extraMessage);
	UPROPERTY(BlueprintAssignable, Category = "TeamSpeak|Callbacks|Server")
	FTeamSpeakOnServerErrorEvent onServerErrorEvent;
	
	DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FTeamSpeakOnServerStopEvent, int32, serverconnectionHandlerID, FString, shutdownMessage);
	UPROPERTY(BlueprintAssignable, Category = "TeamSpeak|Callbacks|Server")
	FTeamSpeakOnServerStopEvent onServerStopEvent;
	
	DECLARE_DYNAMIC_MULTICAST_DELEGATE_SevenParams(FTeamSpeakOnTextMessageEvent, int32, serverconnectionHandlerID, uint32, targetMode, uint32, toID, uint32, fromID, FString, fromName, FString, fromUniqueIdentifier, FString, message);
	UPROPERTY(BlueprintAssignable, Category = "TeamSpeak|Callbacks|Messaging")
	FTeamSpeakOnTextMessageEvent onTextMessageEvent;
	
	DECLARE_DYNAMIC_MULTICAST_DELEGATE_FourParams(FTeamSpeakOnTalkStatusChangedEvent, int32, serverConnectionHandlerID, int32, status, int32, isReceivedWhisper, int32, clientID);
	UPROPERTY(BlueprintAssignable, Category = "TeamSpeak|Callbacks|Talk")
	FTeamSpeakOnTalkStatusChangedEvent onTalkStatusChangeEvent;
	
	DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FTeamSpeakOnIgnoredWhisperEvent, int32, serverconnectionHandlerID, uint32, clientID);
	UPROPERTY(BlueprintAssignable, Category = "TeamSpeak|Callbacks|Talk")
	FTeamSpeakOnIgnoredWhisperEvent onIgnoredWhisperEvent;
	
	DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FTeamSpeakOnConnetrionInfoEvent, int32, serverconnectionHandlerID, uint32, clientID);
	UPROPERTY(BlueprintAssignable, Category = "TeamSpeak|Callbacks|Connection")
	FTeamSpeakOnConnetrionInfoEvent onConnectionInfoEvent;
	
	DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FTeamSpeakOnServerConnectionInfoEvent, int32, serverconnectionHandlerID);
	UPROPERTY(BlueprintAssignable, Category = "TeamSpeak|Callbacks|Connection")
	FTeamSpeakOnServerConnectionInfoEvent onServerConnectionInfoEvent;
	
	DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FTeamSpeakOnChannelSubscribeEvent, int32, serverconnectionHandlerID, int32, channelID);
	UPROPERTY(BlueprintAssignable, Category = "TeamSpeak|Callbacks|Channel")
	FTeamSpeakOnChannelSubscribeEvent onChannelSubscribeEvent;
	
	DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FTeamSpeakOnChannelSubscribeFinishedEvent, int32, serverconnectionHandlerID);
	UPROPERTY(BlueprintAssignable, Category = "TeamSpeak|Callbacks|Channel")
	FTeamSpeakOnChannelSubscribeFinishedEvent onChannelSubscribeFinishedEvent;
	
	DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FTeamSpeakOnChannelUnsubscribeEvent, int32, serverconnectionHandlerID, int32, channelID);
	UPROPERTY(BlueprintAssignable, Category = "TeamSpeak|Callbacks|Channel")
	FTeamSpeakOnChannelUnsubscribeEvent onChannelUnsubscribeEvent;
	
	DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FTeamSpeakOnChannelUnsubscribeFinishedEvent, int32, serverconnectionHandlerID);
	UPROPERTY(BlueprintAssignable, Category = "TeamSpeak|Callbacks|Channel")
	FTeamSpeakOnChannelUnsubscribeFinishedEvent onChannelUnsubscribeFinishedEvent;
	
	DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FTeamSpeakOnChannelDescriptionUpdateEvent, int32, serverconnectionHandlerID, int32, channelID);
	UPROPERTY(BlueprintAssignable, Category = "TeamSpeak|Callbacks|Channel")
	FTeamSpeakOnChannelDescriptionUpdateEvent onChannelDescriptionUpdateEvent;
	
	DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FTeamSpeakOnChannelPasswordChangedEvent, int32, serverconnectionHandlerID, int32, channelID);
	UPROPERTY(BlueprintAssignable, Category = "TeamSpeak|Callbacks|Channel")
	FTeamSpeakOnChannelPasswordChangedEvent onChannelPasswordChangedEvent;
	
	DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FTeamSpeakOnPlaybackShutdownCompleteEvent, int32, serverconnectionHandlerID);
	UPROPERTY(BlueprintAssignable, Category = "TeamSpeak|Callbacks|Device")
	FTeamSpeakOnPlaybackShutdownCompleteEvent onPlaybackShutdownCompleteEvent;
	
	DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FTeamSpeakOnSoundDeviceListChangeEvent, FString, modeID, uint32, playOrCap);
	UPROPERTY(BlueprintAssignable, Category = "TeamSpeak|Callbacks|Device")
	FTeamSpeakOnSoundDeviceListChangeEvent onSoundDeviceListChangedEvent;
	
	DECLARE_DYNAMIC_MULTICAST_DELEGATE_FiveParams(FTeamSpeakOnEditPlaybackVoiceDataEvent, int32, serverconnectionHandlerID, uint32, clientID, TArray<uint32>, samples, uint32, sampleCount, uint32, channels);
	UPROPERTY(BlueprintAssignable, Category = "TeamSpeak|Callbacks|Device")
	FTeamSpeakOnEditPlaybackVoiceDataEvent onEditPlaybackVoiceDataEvent;
	
	DECLARE_DYNAMIC_MULTICAST_DELEGATE_SevenParams(FTeamSpeakOnEditPostProcessVoiceDataEvent, int32, serverconnectionHandlerID, uint32, clientID, TArray<uint32>, samples, uint32, sampleCount, uint32, channels, TArray<uint32>, channelSpeakerArray, TArray<uint32>, channelFillMask);
	UPROPERTY(BlueprintAssignable, Category = "TeamSpeak|Callbacks|Device")
	FTeamSpeakOnEditPostProcessVoiceDataEvent onEditPostProcessVoiceDataEvent;
	
	DECLARE_DYNAMIC_MULTICAST_DELEGATE_SixParams(FTeamSpeakOnEditMixedPlaybackVoiceDataEvent, int32, serverconnectionHandlerID, TArray<uint32>, samples, uint32, sampleCount, uint32, channels, TArray<uint32>, channelSpeakerArray, TArray<uint32>, channelFillMask);
	UPROPERTY(BlueprintAssignable, Category = "TeamSpeak|Callbacks|Device")
	FTeamSpeakOnEditMixedPlaybackVoiceDataEvent onEditMixedPlaybackVoiceDataEvent;
	
	DECLARE_DYNAMIC_MULTICAST_DELEGATE_FiveParams(FTeamSpeakOnEditCapturedVoiceDataEvent, int32, serverconnectionHandlerID, TArray<uint32>, samples, uint32, sampleCount, uint32, channels, TArray<uint32>, edited);
	UPROPERTY(BlueprintAssignable, Category = "TeamSpeak|Callbacks|Device")
	FTeamSpeakOnEditCapturedVoiceDataEvent onEditCapturedVoiceDataEvent;
	
	DECLARE_DYNAMIC_MULTICAST_DELEGATE_FourParams(FTeamSpeakOnCustom3dRolloffCalculationClientEvent, int32, serverconnectionHandlerID, uint32, clientID, float, distance, TArray<float>, volume);
	UPROPERTY(BlueprintAssignable, Category = "TeamSpeak|Callbacks|Device")
	FTeamSpeakOnCustom3dRolloffCalculationClientEvent onCustom3dRolloffCalculationClientEvent;
	
	DECLARE_DYNAMIC_MULTICAST_DELEGATE_FourParams(FTeamSpeakOnCustom3dRolloffCalculationWaveEvent, int32, serverconnectionHandlerID, int32, waveHandle, float, distance, TArray<float>, volume);
	UPROPERTY(BlueprintAssignable, Category = "TeamSpeak|Callbacks|Device")
	FTeamSpeakOnCustom3dRolloffCalculationWaveEvent onCustom3dRolloffCalculationWaveEvent;
	
	DECLARE_DYNAMIC_MULTICAST_DELEGATE_SixParams(FTeamSpeakOnUserLoggingMessageEvent, FString, logMessage, uint32, logLevel, FString, logChannel, int32, logID, FString, logTime, FString, completeLogString);
	UPROPERTY(BlueprintAssignable, Category = "TeamSpeak|Callbacks|Message")
	FTeamSpeakOnUserLoggingMessageEvent onUserLoggingMessageEvent;
/*
	DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FTeamSpeakOnCustomPacketEncryptEvent, TArray<FString>, dataToSend, int32, sizeofData);
	UPROPERTY(BlueprintAssignable, Category = "TeamSpeak|Callbacks|Crypt")
	FTeamSpeakOnCustomPacketEncryptEvent onCustomPacketEncryptEvent;
	
	DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FTeamSpeakOnCustomPacketDecryptEvent, TArray<FString>, dataReceived, int32, sizeofData);
	UPROPERTY(BlueprintAssignable, Category = "TeamSpeak|Callbacks|Crypt")
	FTeamSpeakOnCustomPacketDecryptEvent onCustomPacketDecryptEvent;
*/
	DECLARE_DYNAMIC_MULTICAST_DELEGATE_ThreeParams(FTeamSpeakOnProvisioningSlotRequestedResultEvent, uint32, error, int32, requestHandle, FString, connectionKey);
	UPROPERTY(BlueprintAssignable, Category = "TeamSpeak|Callbacks|Connection")
	FTeamSpeakOnProvisioningSlotRequestedResultEvent onProvisioningSlotRequestResultEvent;
	
	DECLARE_DYNAMIC_MULTICAST_DELEGATE_ThreeParams(FTeamSpeakOnCheckServerUniqueIdentifierEvent, int32, serverConnectionHandlerID, FString, serverUniqueidentifier, TArray<uint32>, cancelConnect);
	UPROPERTY(BlueprintAssignable, Category = "TeamSpeak|Callbacks|Server")
	FTeamSpeakOnCheckServerUniqueIdentifierEvent onCheckServerUniqueIdentifierEvent;

	DECLARE_DYNAMIC_MULTICAST_DELEGATE_FourParams(FTeamSpeakOnClientPasswordEncrypt, int32, serverconnectionHandlerID, FString, plaint32ext, FString, encryptedText, int32, encryptedTextByteSize);
	UPROPERTY(BlueprintAssignable, Category = "TeamSpeak|Callbacks|Crypt")
	FTeamSpeakOnClientPasswordEncrypt onClientPasswordEncrypt;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TeamSpeak|Enum")
	ETeamSpeak_TalkStatus TalkStatus;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TeamSpeak|Enum")
	ETeamSpeak_CodecType CodecType;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TeamSpeak|Enum")
	ETeamSpeak_CodecEncryptionMode CodecEncryptionMode;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TeamSpeak|Enum")
	ETeamSpeak_TextMessageTargetMode TextMessageTargetMode;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TeamSpeak|Enum")
	ETeamSpeak_MuteInputStatus MuteInputStatus;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TeamSpeak|Enum")
	ETeamSpeak_MuteOutputStatus MuteOutputStatus;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TeamSpeak|Enum")
	ETeamSpeak_HardwareInputStatus HardwareInputStatus;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TeamSpeak|Enum")
	ETeamSpeak_HardwareOutputStatus HardwareOutputStatus;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TeamSpeak|Enum")
	ETeamSpeak_InputDeactivationStatus InputDeactivationstatus;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TeamSpeak|Enum")
	ETeamSpeak_ReasonIdentifier ReasonIdentifier;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TeamSpeak|Enum")
	ETeamSpeak_ChannelProperties ChannelProperties;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TeamSpeak|Enum")
	ETeamSpeak_ClientProperties ClientProperties;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TeamSpeak|Enum")
	ETeamSpeak_VirtualServerProperties VirtualServerProperties;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TeamSpeak|Enum")
	ETeamSpeak_LogTypes LogTypes;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TeamSpeak|Enum")
	ETeamSpeak_LogLevel LogLevel;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TeamSpeak|Enum")
	ETeamSpeak_GroupWhisperType GroupWhisperType;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TeamSpeak|Enum")
	ETeamSpeak_GroupWhisperTargetMode GroupWhisperTargetMode;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TeamSpeak|Enum")
	ETeamSpeak_MonoSoundDestination MonoSoundDestination;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TeamSpeak|Enum")
	ETeamSpeak_SecuritySaltOptions SecuritySaltOptions;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TeamSpeak|Enum")
	ETeamSpeak_ClientCommand ClientCommand;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TeamSpeak|Enum")
	ETeamSpeak_ACLType ACLType;

private:
	static TSharedPtr<TeamSpeak_Manager> ts_Manager;
	static UTeamSpeakFunctionLibrary* utsFL;
};
