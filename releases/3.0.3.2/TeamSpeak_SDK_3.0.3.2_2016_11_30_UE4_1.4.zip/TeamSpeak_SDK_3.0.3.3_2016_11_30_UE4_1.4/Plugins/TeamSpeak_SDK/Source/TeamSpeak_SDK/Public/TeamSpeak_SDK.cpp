

#include "TeamSpeak_SDK.h"

IMPLEMENT_GAME_MODULE( FDefaultGameModuleImpl, TeamSpeak_SDK );
