
using System.IO;
using UnrealBuildTool;

public class TeamSpeak_SDK : ModuleRules
{
	public TeamSpeak_SDK(TargetInfo Target)
	{		
		PublicDependencyModuleNames.AddRange(new string[] { "Core", "CoreUObject", "Engine", "InputCore" });

		PrivateDependencyModuleNames.AddRange(new string[] {  });

		// Uncomment if you are using Slate UI
		// PrivateDependencyModuleNames.AddRange(new string[] { "Slate", "SlateCore" });
		
		// Uncomment if you are using online features
		// PrivateDependencyModuleNames.Add("OnlineSubsystem");
		// if ((Target.Platform == UnrealTargetPlatform.Win32) || (Target.Platform == UnrealTargetPlatform.Win64))
		// {
		//		if (UEBuildConfiguration.bCompileSteamOSS == true)
		//		{
		//			DynamicallyLoadedModuleNames.Add("OnlineSubsystemSteam");
		//		}
		// }
        LoadTeamSpeakLib(Target);
	}

    private string ModulePath
    {
        get { return ModuleDirectory; }
    }

    private string ThirdPartyPath
    {
        get { return Path.GetFullPath(Path.Combine(ModulePath, "../../ThirdParty/")); }
    }    
 
    public bool LoadTeamSpeakLib(TargetInfo Target) {
        bool isLibrarySupported = false;
 
        if(Target.Platform == UnrealTargetPlatform.Win64) {
            isLibrarySupported = true;
            string LibrariesPath = Path.Combine(ThirdPartyPath, "TeamSpeak_lib", "Libraries");
            PublicAdditionalLibraries.Add(Path.Combine(LibrariesPath, "ts3client_win64.lib"));

            var path = CopyToBinaries(Path.Combine(ThirdPartyPath, "ts3client_win64.dll"), Target);
            var dllPath = new RuntimeDependency(path);
            RuntimeDependencies.Add(dllPath);                        
        } else if (Target.Platform == UnrealTargetPlatform.Win32) {
            isLibrarySupported = true;
            string LibrariesPath = Path.Combine(ThirdPartyPath, "TeamSpeak_lib", "Libraries");
            PublicAdditionalLibraries.Add(Path.Combine(LibrariesPath, "ts3client_win32.lib"));

            var path = CopyToBinaries(Path.Combine(ThirdPartyPath, "ts3client_win32.dll"), Target);
            var dllPath = new RuntimeDependency(path);
            RuntimeDependencies.Add(dllPath);
        }
        
        if(isLibrarySupported) {
            PublicIncludePaths.Add(Path.Combine(ThirdPartyPath, "TeamSpeak_lib", "Includes"));
        }
 
        Definitions.Add(string.Format( "WITH_BOBS_MAGIC_BINDING={0}", isLibrarySupported ? 1 : 0 ) );
 
		Definitions.Add("TS_MODULE_INTERNAL");
 
		PublicIncludePaths.Add(Path.Combine(GetUProjectPath(), "Plugins"));
		PublicIncludePaths.Add(Path.Combine(GetUProjectPath(), "Plugins/TeamSpeak_SDK/Source/TeamSpeak_SDK/Public"));
 
        return isLibrarySupported;
    }

    public string GetUProjectPath()
    {
        return Directory.GetParent(ModulePath).Parent.FullName;
    }
    public string GetGameDir()
    {
        return Directory.GetParent(ModulePath).Parent.Parent.Parent.FullName;
    }

    private string CopyToBinaries(string Filepath, TargetInfo Target)
    {
        string binariesDir = Path.Combine(GetGameDir(), "Binaries", Target.Platform.ToString());
        string filename = Path.GetFileName(Filepath);

        if (!Directory.Exists(binariesDir))
            Directory.CreateDirectory(binariesDir);

        string binPath = Path.Combine(binariesDir, filename);
        if (!File.Exists(Path.Combine(binariesDir, filename)))
            File.Copy(Filepath, binPath, true);

        return binPath;
    }
}
