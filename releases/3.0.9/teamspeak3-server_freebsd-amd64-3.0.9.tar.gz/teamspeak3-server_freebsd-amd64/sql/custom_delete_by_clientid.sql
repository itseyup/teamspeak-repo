delete from custom_fields where server_id=:server_id: and client_id=:client_id:;
