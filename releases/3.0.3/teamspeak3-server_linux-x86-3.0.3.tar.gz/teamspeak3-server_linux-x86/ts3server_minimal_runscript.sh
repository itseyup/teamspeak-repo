#!/bin/sh

export LD_LIBRARY_PATH=".:$LD_LIBRARY_PATH"

D1=$(readlink -f "$0")
D2=$(dirname "${D1}")
cd "${D2}"

if [ -e ts3server_linux_x86 ]; then
	./ts3server_linux_x86 $@
elif [ -e ts3server_linux_amd64 ]; then
	./ts3server_linux_amd64 $@
elif [ -e ts3server_freebsd_x86 ]; then
	./ts3server_freebsd_x86 $@
elif [ -e ts3server_freebsd_amd64 ]; then
	./ts3server_freebsd_amd64 $@
else
	echo 'Could not find binary, aborting'
fi

