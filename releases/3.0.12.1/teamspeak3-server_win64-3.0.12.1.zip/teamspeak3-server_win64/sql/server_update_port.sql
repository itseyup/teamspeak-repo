update servers set server_port= :server_port: where server_id=:server_id:;
