INSERT INTO servers 
( server_autostart, server_port, server_machine_id) 
VALUES
( :server_autostart:, :server_port:, :server_machine_id:);
