#############################################
                    TSDNS
#############################################


TS DNS is a system that allows TeamSpeak users to connect to servers that are
running on arbitrary ports without having to specify the port. The "TSDNS name"
is used by the system to determine IP and Port. It can be compared to some
extent to the "Virtual Host" system of Apache in its purpose, though the
technical aspects are very much different.

Motivation
----------
Say you own a server running on the IP 1.2.3.4 and Port 4321. Telling people
you want to join your server to join "1.2.3.4:4321" or (using regular DNS)
"myclanrocks.net:4321" works, but the port there is an extra source of
confusion to inexperienced users. It would be nice if you could just tell
people to join "myclanrocks.net" (as if your TS server were running on the
default port).

How it works
------------
A TSDNS server is a very simple network service that uses TCP/IP to listen on
port 41144 and knows a list of (query,result) pairs. Upon connecting to the
TSDNS server you must submit your query and the TSDNS server will answer you
with the result, if it has this query in his list, or with "404" if no such
query is known to it. The result is supposed to be either an IP (which assumes
a port of 9987) or an IP:Port pair. Instead of a number as port the special
string "$PORT" is also allowed, which results in any port specified on the
client side to be used.

Whenever a TeamSpeak Client tries to connect to a server using a hostname,
it will try to connect to up to three possible TSDNS servers to try and
retrieve a (IP, Port) pair using the hostname as string that the TSDNS server
is queried with.

Illustration:
hostname=voice.teamspeak.com
TSDNS Server asked queried are:
- voice.teamspeak.com (with query = voice.teamspeak.com)
- teamspeak.com       (with query = voice.teamspeak.com)
- com                 (with query = voice.teamspeak.com)

Second Example (with longer hostname)
hostname=i.will.roxx.your.soxs.myclan.com
- soxs.myclan.com     (with query = i.will.roxx.your.soxs.myclan.com)
- myclan.com          (with query = i.will.roxx.your.soxs.myclan.com)
- com                 (with query = i.will.roxx.your.soxs.myclan.com)

Third Example (with short hostname)
hostname=myclanrocks.net
- myclanrocks.net     (with query = myclanrocks.net)
- net                 (with query = myclanrocks.net)

If any of these succeed to retrieve an answer from a TSDNS server the one to
answer first is used to connect. If all of the above TSDNS server queries fail
(usually due to no TSDNS servers running on the (up to) three hosts), the
TeamSpeak Client will fall back to a regular DNS resolve of the hostname.

