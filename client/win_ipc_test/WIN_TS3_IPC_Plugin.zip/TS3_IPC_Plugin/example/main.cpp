#include <Windows.h>
#include <iostream>
#include "connect_teamspeak.h"

using namespace std;

int main() {
	// Get identity and nickname
	TSPropertyValue valIdentity, valNickname;
	TSC_InitPropertyValue(&valIdentity);
	TSC_InitPropertyValue(&valNickname);

	HIdentity hIdentity;
	TSCError error = TSC_GetIdentityByName("Standard", &hIdentity);
	if(error != TSCE_Success) {
		cerr << "Error getting identity \"Standard\": " << error << endl;
		return EXIT_FAILURE;
	}
	cout << "Got identity \"Standard\"" << endl;
	error = TSC_GetIdentityProperty(hIdentity, TSCIP_Nickname, &valNickname);
	if(error != TSCE_Success) {
		cerr << "Error getting nickname property from identity: " << error << endl;
		return EXIT_FAILURE;
	}
	error = TSC_GetIdentityProperty(hIdentity, TSCIP_Identity, &valIdentity);
	if(error != TSCE_Success) {
		cerr << "Error getting identity property from identity: " << error << endl;
		return EXIT_FAILURE;
	}
	cout << "Nickname: " << TSC_GetAString(valNickname) << ", identity: " << TSC_GetAString(valIdentity) << endl;

	// Check comm status
	TSCClientCommunicationStatus commStatus;
	error = TSC_QueryTSClientCommunicationStatus(&commStatus);
	cout << "Query comm status: " << error << " " << commStatus << endl;
	if(error != TSCE_Success) {
		cerr << "Error querying comm status: " << error << endl;
		return EXIT_FAILURE;
	}

	if(commStatus == TSCCCS_NoConnection) {
		// Start client
		cout << "Not yet connected, start client" << endl;
		error = TSC_StartTSClient();
		cout << "Start client: " << error << endl;
		if(error != TSCE_Success) {
			cerr << "Error starting TS3 client: " << error << endl;
			return EXIT_FAILURE;
		}
		cout << "Client started" << endl;

		// Init connection
		error = TSC_ConnectToTSClient();
		cout << "Connect to client: " << error << endl;
		if(error != TSCE_Success) {
			cerr << "Error connecting to TS3 client: " << error << endl;
			return EXIT_FAILURE;
		}
		cout << "Connected to client" << endl;
	}

	cout << "Connection to TS3 client available" << endl;

	// Test client status
	TSCClientStatus clientStatus;
	error = TSC_QueryTSClientStatus(&clientStatus);
	cout << "Client status: " << error << " " << clientStatus << endl;
	if(error != TSCE_Success) {
		cerr << "Error querying TS3 client status: " << error << endl;
		return EXIT_FAILURE;
	}
	if(clientStatus == TSCCS_Inactive) {
		cerr << "No client active, aborting..." << endl;
		return EXIT_FAILURE;
	}

	Sleep(1000);

	// Get current virtual server handle
	HVirtualServer hVirtualServer;
	error = TSC_GetCurrentVirtualServer(&hVirtualServer);
	if(error != TSCE_Success) {
		cerr << "Error getting current virtual server handle: " << error << endl;
		return EXIT_FAILURE;
	}
	cout << "Got virtual server handle" << endl;

	// Display virtual server ID of handle
	uint64 scHandlerID = TSC_QueryVirtualServerID(hVirtualServer, &error);
	if(error != TSCE_Success) {
		cerr << "Error querying virtual server ID of virtual server handle: " << error << endl;
		return EXIT_FAILURE;
	}
	cout << "scHandlerID = " << scHandlerID << endl;

	// Connect to localhost TS3 server
	const char* defaultChannelArray[] = { "test", "" };
	error = TSC_StartConnection(hVirtualServer, TSC_GetAString(valIdentity), "localhost", 9987, TSC_GetAString(valNickname), defaultChannelArray, "", "");
	if(error != TSCE_Success) {
		cerr << "Error connecting to localhost TS3 server: " << error << endl;
		//return EXIT_FAILURE;  No error, Probably already connected
	}
	cout << "Start connection called" << endl;

	Sleep(100);

	// Display own client ID
	HClient hClient;
	error = TSC_GetClientHandle(hVirtualServer, &hClient);
	if(error != TSCE_Success) {
		cerr << "Error getting client handle: " << error << endl;
		return EXIT_FAILURE;
	}
	anyID clientID = TSC_QueryClientID(hClient, &hVirtualServer, &error);
	if(error != TSCE_Success) {
		cerr << "Error querying clientID: " << error << endl;
		return EXIT_FAILURE;
	}
	cout << "clientID = " << clientID << endl;

	Sleep(100);

	// Disconnect
	error = TSC_DisconnectTSClient();
	cout << "Disconnect: " << error << endl;
	if(error != TSCE_Success) {
		cerr << "Error disconnecting from TS3 client: " << error << endl;
		return EXIT_FAILURE;
	}
	cout << "Disconnected, bye..." << endl;

	return EXIT_SUCCESS;
}
