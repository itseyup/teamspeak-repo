#pragma once

#include "public_definitions.h"

#ifdef _MSC_VER
	#define TSCALLBACK __stdcall
	#ifndef TSCAPI
	#define TSCAPI __declspec(dllimport)
	#endif
#else
	#error Undefined TSCALLBACK
	#define TSCAPI __attribute__ ((visibility("default")))
#endif

/* uuid_t declaration */
#ifdef _MSC_VER

#ifndef GUID_DEFINED
#include <guiddef.h>
#endif /* GUID_DEFINED */

#ifndef UUID_DEFINED
	#define UUID_DEFINED
	typedef GUID UUID;
	#ifndef uuid_t
		#define uuid_t UUID
	#endif
#endif
#else
#error uuid_t undefined!
#endif

#ifndef _WCHAR_T_DEFINED
typedef unsigned short wchar_t;
#endif

#ifndef DECLARE_TSHANDLE
#define DECLARE_TSHANDLE(name) struct name##_hstruct { int unused; }; typedef struct name##_hstruct *name;
#endif

DECLARE_TSHANDLE(TSBOOKMARKDBCALLBACKHANDLE)
DECLARE_TSHANDLE(HBookmarkFolder)
DECLARE_TSHANDLE(HBookmark)
DECLARE_TSHANDLE(TSCALLBACKHANDLE)
DECLARE_TSHANDLE(HIdentity)
DECLARE_TSHANDLE(HVirtualServer)
DECLARE_TSHANDLE(HClient)
DECLARE_TSHANDLE(HChannel)
DECLARE_TSHANDLE(TSPLUGINCALLBACKHANDLE)

/*
Error codes
*/
typedef enum TSCError_ {
	TSCE_Success = 0,
	TSCE_InvalidHandle = 1,
	TSCE_NotEnoughData = 2,
	TSCE_NoMemory = 3,
	TSCE_ForeignBuffer = 4,
	TSCE_UnableToConvert = 5,
	TSCE_ConnectionInitiated = 6,
	TSCE_InvalidPropertyId = 7,
	TSCE_InvalidParameter = 8,
	TSCE_PropertyInaccessible = 9,
	TSCE_NotImplemented = 10,
	TSCE_ClientNotFound = 11,
	TSCE_NegativeOverflow = 12, /* Actually this is warning, the code never returned but placed in conversionError */
	TSCE_PositiveOverflow = 13, /* Same as NegativeOverflow */
	TSCE_InvalidIdentifier = 14,
	TSCE_UnexpectedFailure = 15,
	TSCE_PendingQuery = 16,
	TSCE_TSClientReportsError = 17,
	TSCE_NoConnection = 18,
	TSCE_TimeoutExpired = 19,
	TSCE_InvalidData = 20,
	TSCE_ErrorsInGroup = 21,
	TSCE_NotFound = 22 // Search criteries are no satisfied
} TSCError;

typedef enum TSCPropertyType_ {
	TSCPT_Null = 0,
	TSCPT_String = 1,
	TSCPT_WString = 2,
	TSCPT_UInt4 = 3,
	TSCPT_Int4 = 4,
	TSCPT_UInt8 = 5,
	TSCPT_Int8 = 6,
	TSCPT_UUID = 7,
	TSCPT_Double = 8,// ?
	TSCPT_Blob = 9,
	TSCPT_MAX = TSCPT_Blob + 1
} TSCPropertyType;

/*
TeamSpeak properties flags
*/
#define TSPF_READ					0x1U
#define TSPF_WRITE					0x2U
#define TSPF_READWRITE	(TSPF_READ|TSPF_WRITE)

#define TEAMSPEAK_PROPERTY_NAME_LENGTH 55

#define TSPV_ALLOWBUFFERALLOC		0x1U
#define TSPV_BUFFERALLOCATEDBYTS	0x2U

/* Special flag to initialize */
#define TSPV_EMPTY					0x4U

typedef enum TSCBookmarkDBEvent_ {
	TSCBDE_Save = 1, /* Just ordinal save without transaction */
	TSCBDE_Load = 2, /* Reloaded due to file monitoring */
	TSCBDE_Commit = 3, /* Commit transaction */
	TSCBDE_Rollback = 4, /* Rollback transaction */
	TSCBDE_NeedRefresh = 5, /* Disk content was updated but database in memory still kept not refreshed */
} TSCBookmarkDBEvent;

typedef void (TSCALLBACK* TSBOOKMARKDBCALLBACK) (TSCBookmarkDBEvent, void *);

#define TS_ROOT_BOOKMARK_FOLDER ((HBookmarkFolder)NULL)

/*! Identifiers of bookmark folders properties. */
typedef enum TSCBookmarkFolderPropertyId_ {
	/*! Unique id of the folder, read-only */
	TSCBFP_UUID = 1,
	/*! Name of the folder, read-write */
	TSCBFP_Name = 2,
	/*! Count of Folders + Bookmarks, read-only */
	TSCBFP_SubItemCount = 3,
	/*! Count subfolders only, read-only */
	TSCBFP_SubFolderCount = 4,
	/*! Count bookmarks inserted into particular folder. Read-only. */
	TSCBFP_SubBookmarkCount = 5
} TSCBookmarkFolderPropertyId;

typedef enum TSCBookmarkPropertyId_ {
	TSCBP_UUID = 1,
	TSCBP_Name = 2,
	TSCBP_Address = 3,
	TSCBP_Port = 4,
	TSCBP_CaptureProfile = 5,
	TSCBP_PlaybackProfile = 6,
	TSCBP_Identity = 7,
	TSCBP_Nick = 8,
	TSCBP_PhoneticsNickname = 9,
	TSCBP_DefaultChannel = 10,
	TSCBP_Autoconnect = 11,
	TSCBP_ServerUID = 12,
	TSCBP_HotkeyProfile = 13,
	TSCBP_Icon = 14,
	TSCBP_Count = 15,
	TSCBP_Last = 16,
	TSCBP_Total = 17,
	TSCBP_Clients = 18,
	TSCBP_Password = 19
} TSCBookmarkPropertyId;

/*
Client status
*/
typedef enum TSCClientStatus_ {
	TSCCS_Active = 0,
	TSCCS_Inactive
} TSCClientStatus;

/*
Status of connection between the library & client.
*/
typedef enum TSCClientCommunicationStatus_ {
	/*! No connection now, no pending. */
	TSCCCS_NoConnection,
	/*! Communications initialized but there is still no active connection. */
	TSCCCS_BeingConnected,
	/*! TeamSpeak client connected. */
	TSCCCS_Connected
} TSCClientCommunicationStatus;

#define TSC_LAST_TSCLIENT_ERROR_NOT_AVAILABLE 0xFFFFFFFF

typedef enum TSCIdentityPropertyId_ {
	TSCIP_Name = 1,
	TSCIP_Nickname = 2,
	TSCIP_Identity = 3
} TSCIdentityPropertyId;

typedef enum VirtualServerProperties TSCVirtualServerPropertyId;
typedef enum ConnectionProperties TSCConnectionPropertyId;
typedef enum ClientProperties TSCClientPropertyId;
typedef enum ChannelProperties TSCChannelPropertyId;

typedef enum TSCConnectionLibraryPropertyId_ {
	TSCCLP_LibVersion = 1,
	TSCCLP_PluginVersion = 2,
	TSCCLP_PluginAPIVersion = 3,
	TSCCLP_ProtocolVersion = 4,
	TSCCLP_CurrentProtocolVersion = 5,
	TSCCLP_TSClientVersion = 6,

	/*!\{*/
	/*! Reflection to 'client functions' of TS3Functions. */
	TSCCLP_AppPath = 7,
	TSCCLP_ResourcesPath = 8,
	TSCCLP_ConfigPath = 9,
	TSCCLP_PluginPath = 10,
	TSCCLP_CurrentServerConnectionHandlerID = 11,
	TSCCLP_ClientLibVersion = 12
	/*!\}*/
} TSCConnectionLibraryPropertyId;


typedef struct TSPropertyTraits_ {
	unsigned flags;
	TSCPropertyType type;
	char name[TEAMSPEAK_PROPERTY_NAME_LENGTH + 1]; // ?: Is it need?
} TSPropertyTraits;

typedef struct TSPropertyValue_ {
	TSCPropertyType type; /* Requested type */
	unsigned long flags; /* TSPV_ constants */
	union {
		long lVal;
		unsigned long ulVal;
		long long llVal;
		unsigned long long ullVal;
		double dblVal;
		uuid_t uuidVal;
		struct AStringValue {
			unsigned long langCode;
			char *buffer;
			unsigned long length; // In chars
		} strVal;
		struct WStringValue {
			wchar_t *buffer;
			unsigned long length; // In wchar_t's
		} wstrVal;
		struct BlobValue {
			void *buffer;
			unsigned long bufferSize; // In chars
		} blobVal;
	};
	unsigned long extraChars; // Output for creation/conversion functions
	TSCError conversionError; // Output for creation/conversion functions
} TSPropertyValue;

/*!\addtogroup APIBookmarkFolder */
/*!\{*/

/*! Type of folder item */
typedef enum TSCFolderItemType_ {
	TSCFIT_Folder = 1,
	TSCFIT_Bookmark = 2
} TSCFolderItemType;

/*! Aggregate to request/retrieve values of bookmark folder properties */
typedef struct TSBookmarkFolderIdentifiedProp_ {
	/*! Identifier of the property (see \ref TSCBookmarkFolderPropertyId) */
	TSCBookmarkFolderPropertyId id;
	/*! Value of the property, identified by \ref id member */
	TSPropertyValue value;
} TSBookmarkFolderIdentifiedProp;

/*! Aggregate to request/retrieve traits of bookmark folder properties */
typedef struct TSBookmarkFolderIdentifiedPropTraits_ {
	/*! Identifier of the property (see \ref TSCBookmarkFolderPropertyId) */
	TSCBookmarkFolderPropertyId id;
	/*! Traits of the property, identified by \ref id member */
	TSPropertyTraits traits;
} TSBookmarkFolderIdentifiedPropTraits;

typedef long (TSCALLBACK* TSFOLDERENUMPROC) (uuid_t, TSCFolderItemType, void *);
/*!\}*/

/*!\{*/
typedef struct TSBookmarkIdentifiedProp_ {
	TSCBookmarkPropertyId id;
	TSPropertyValue value;
} TSBookmarkIdentifiedProp;

typedef struct TSBookmarkIdentifiedPropTraits_ {
	TSCBookmarkPropertyId id;
	TSPropertyTraits traits;
} TSBookmarkIdentifiedPropTraits;
/*!\}*/

typedef struct TSIdentityIdentifiedProp_ {
	TSCIdentityPropertyId id;
	TSPropertyValue value;
} TSIdentityIdentifiedProp;

typedef struct TSIdentityIdentifiedPropTraits_ {
	TSCIdentityPropertyId id;
	TSPropertyTraits traits;
} TSIdentityIdentifiedPropTraits;

typedef struct TSVirtualServerIdentifiedProp_ {
	TSCVirtualServerPropertyId id;
	TSPropertyValue value;
} TSVirtualServerIdentifiedProp;

typedef struct TSVirtualServerIdentifiedPropTraits_ {
	TSCVirtualServerPropertyId id;
	TSPropertyTraits traits;
} TSVirtualServerIdentifiedPropTraits;

typedef struct TSConnectionIdentifiedProp_ {
	TSCConnectionPropertyId id;
	TSPropertyValue value;
} TSConnectionIdentifiedProp;

typedef struct TSConnectionIdentifiedPropTraits_ {
	TSCConnectionPropertyId id;
	TSPropertyTraits traits;
} TSConnectionIdentifiedPropTraits;

typedef struct TSClientSelfIdentifiedProp_ {
	TSCClientPropertyId id;
	TSPropertyValue value;
} TSClientSelfIdentifiedProp;

typedef struct TSClientSelfIdentifiedPropTraits_ {
	TSCClientPropertyId id;
	TSPropertyTraits traits;
} TSClientSelfIdentifiedPropTraits;

typedef struct TSClientIdentifiedProp_ {
	TSCClientPropertyId id;
	TSPropertyValue value;
} TSClientIdentifiedProp;

typedef struct TSClientIdentifiedPropTraits_ {
	TSCClientPropertyId id;
	TSPropertyTraits traits;
} TSClientIdentifiedPropTraits;

typedef struct TSChannelIdentifiedProp_ {
	TSCChannelPropertyId id;
	TSPropertyValue value;
} TSChannelIdentifiedProp;

typedef struct TSChannelIdentifiedPropTraits_ {
	TSCChannelPropertyId id;
	TSPropertyTraits traits;
} TSChannelIdentifiedPropTraits;

typedef struct TSConnectionLibraryIdentifiedProp_ {
	TSCConnectionLibraryPropertyId id;
	TSPropertyValue value;
} TSConnectionLibraryIdentifiedProp;

typedef struct TSConnectionLibraryIdentifiedPropTraits_ {
	TSCConnectionLibraryPropertyId id;
	TSPropertyTraits traits;
} TSConnectionLibraryIdentifiedPropTraits;
