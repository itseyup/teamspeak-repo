#pragma once

/*
Task:
- query teamspeak 3 bookmarks (even while client offline)
- connect to a ts3 server (launches the client if necessary)
  (either via IP/Hostname or you can specify a bookmark number to join)
- query if a client is already running
- query which server(s) a user is currently connected to (so you could provide
  this information about other users so you can "follow" your buddy to a TS server)
- query the channels of each server you are connected to
- query the visible clients of each server you are connected to
- get notifications when somebody starts and stops talking, notifications about new channels, channels deletions, when you disconnect/connect, users connect/disconnect, switch channels
*/

#include "connect_teamspeak_definitions.h"
#include "connect_teamspeak_notifications.h"

#ifdef __cplusplus
extern "C" {
#endif

/*
Common functions
*/
TSCAPI TSCError TSC_Malloc(unsigned bytes, void **ppBuffer);
TSCAPI TSCError TSC_Free(void *pBuffer);
TSCAPI TSCError TSC_Realloc(void *pOldBuffer, unsigned bytes, void **ppBuffer);

/*
Exception handlers
*/
/*
TODO: think about exceptions in external callbacks taking in account C issues

typedef void (TSCALLBACK* TSCALLBACKEXCEPTIONHANDLER) (, void*);
DECLARE_TSHANDLE(TSCALLBACKHANDLE)
*/

/* Normal initialization, preserve TSRV_ALLOWBUFFERALLOC flag */
TSCAPI TSCError TSC_InitPropertyValue(TSPropertyValue *);
TSCAPI TSCError TSC_FreePropertyValue(TSPropertyValue *);
TSCAPI TSCError TSC_CreatePropertyValueArray(TSPropertyValue **ppArray, unsigned long size);
TSCAPI TSCError TSC_FreePropertyValueArray(TSPropertyValue *pArray);
TSCAPI TSCError TSC_GetPropertyValueArraySize(const TSPropertyValue *pArray, unsigned long *pSize);
TSCAPI TSCError TSC_ResizePropertyValueArray(TSPropertyValue **ppArray, unsigned long newSize);

/* TSC_InitXXXXXValue functions ignores target value flags,
   buffer is always treated as 'external' one */
TSCAPI TSCError TSC_InitAStringValue(TSPropertyValue *, unsigned long lang, const char *, unsigned length);
TSCAPI TSCError TSC_InitWStringValue(TSPropertyValue *, unsigned long lang, const char *, unsigned length);
TSCAPI TSCError TSC_InitWStringValueW(TSPropertyValue *, const wchar_t *, unsigned length);
TSCAPI TSCError TSC_InitInt4Value(TSPropertyValue *, long);
TSCAPI TSCError TSC_InitUInt4Value(TSPropertyValue *, unsigned long);
TSCAPI TSCError TSC_InitInt8Value(TSPropertyValue *, long long int);
TSCAPI TSCError TSC_InitUInt8Value(TSPropertyValue *, unsigned long long);
TSCAPI TSCError TSC_InitUUIDValue(TSPropertyValue *, const uuid_t *);
TSCAPI TSCError TSC_InitBlobValue(TSPropertyValue *, const void *, unsigned);

/* TSC_CreateXXXXXValue functions analyzes TSPV_ALLOWBUFFERALLOC flag */
TSCAPI TSCError TSC_CreateAStringValue(TSPropertyValue *, unsigned long lang, const char *, unsigned length);
TSCAPI TSCError TSC_CreateWStringValue(TSPropertyValue *, unsigned long lang, const char *, unsigned length);
TSCAPI TSCError TSC_CreateWStringValueW(TSPropertyValue *, const wchar_t *, unsigned length);
TSCAPI TSCError TSC_CreateInt4Value(TSPropertyValue *, long);
TSCAPI TSCError TSC_CreateUInt4Value(TSPropertyValue *, unsigned long);
TSCAPI TSCError TSC_CreateInt8Value(TSPropertyValue *, long long int);
TSCAPI TSCError TSC_CreateUInt8Value(TSPropertyValue *, unsigned long long);
TSCAPI TSCError TSC_CreateUUIDValue(TSPropertyValue *, const uuid_t *);
TSCAPI TSCError TSC_CreateBlobValue(TSPropertyValue *, const void *, unsigned);

/*
// pDestValue members have to be initialized before the call:
// flags - with one of TSPV_ constants
// type - with required type code
// buffer pointers - with used buffer parameters, have to be coordinated with 'flags' member value
// langCode - with required language code (if needed)
*/
TSCAPI TSCError TSC_ConvertPropertyValue(TSPropertyValue *pDestValue, const TSPropertyValue *pSrcValue);
TSCAPI TSCError TSC_ConvertPropertyValueInplace(TSPropertyValue *pValue, TSCPropertyType newType, unsigned long newLangCode);
TSCAPI TSCError TSC_CopyPropertyValue(TSPropertyValue *pDestValue, const TSPropertyValue *pSrcValue);
TSCAPI long TSC_ComparePropertyValue(const TSPropertyValue *pLeft, const TSPropertyValue *pRight, TSCError *pError);

#define CLEAR_IDENTIFIED_PROPVALUE_ARRAY(propArray, size, counter) \
for(counter = 0; counter < size; ++counter) \
	if (propArray[counter].value.flags & TSPV_BUFFERALLOCATEDBYTS) \
		TSC_FreeStringProperty(&propArray[counter].value); \

/*! Helper macro to retrieve string content of property value of appropriate type */
#define TSC_GetAString(propValue) propValue.strVal.buffer
/*! Helper macro to retrieve wide-char string content of property value of appropriate type */
#define TSC_GetWString(propValue) propValue.wstrVal.buffer
/*! Helper macro to cleanup error codes in property value */
#define TSC_ResetConversionErrors(propValue) do { propValue.conversionError = TSCE_Success; propValue.extraChars = 0; } while(0)

/*!\addtogroup APIBookmarks*/
/*\{*/

/*
Bookmarks/bookmark folders database
*/

/*!\addtogroup APIBookmarksDB */
/*\{*/

TSCAPI TSCError TSC_SetBookmarkDBAutoRefresh(unsigned long); /* 1/0 */
TSCAPI TSCError TSC_GetBookmarkDBAutoRefresh(unsigned long *);
TSCAPI TSCError TSC_RefreshBookmarkDB();
TSCAPI TSCError TSC_BeginBookmarkDBTransaction();
TSCAPI TSCError TSC_CommitBookmarkDB();
TSCAPI TSCError TSC_RollbackBookmarkDB();
TSCAPI TSCError TSC_GetBookmarkDBTimeStamp(long long *);

/* Returns !=0 when someone transaction is active */
TSCAPI unsigned long TSC_BookmarkDBHasActiveTransaction();

/* Returns != when database cache is updated but not flushed */
TSCAPI unsigned long TSC_BookmarkDBIsDirt();

TSCAPI TSCError TSC_SetBookmarkDBStatusCallback(TSBOOKMARKDBCALLBACK, void *data, TSBOOKMARKDBCALLBACKHANDLE *phCallback);
TSCAPI TSCError TSC_RemoveBookmarkDBStatusCallback(TSBOOKMARKDBCALLBACKHANDLE hCallback);
TSCAPI TSCError TSC_RemoveAllBookmarkDBStatusCallbacks();
/*\}*/

/*!\addtogroup APIBookmarkFolder */
/*\{*/

TSCAPI TSCError TSC_OpenBookmarkFolderByUuid(const uuid_t *uuid, HBookmarkFolder *pHResult);

/*! Creates handle for particular bookmark folder.
\param[in] hParent Handle of parent folder (should be retrieved by previous call of \ref TSC_OpenBookmarkFolder or \ref TS_ROOT_BOOKMARK_FOLDER may be used).
\param[in] uuid Pointer to unique identifier of the folder. The Identifier should identify item of \ref TSCFIT_Folder type, otherwise function fails.
\param[out] pHResult Pointer to receive handle to requested folder. No changes when function fails. The pointer can't be NULL.
\retval TSCE_Success Everything normal.
\retval TSCE_InvalidParameter The one of \a uuid or \a pHResult parameters is NULL.
\retval TSCE_InvalidIdentifier Unable to locate subfolder identified by \a uuid.
\retval TSCE_InvalidHandle \a hParent is wrong (or closed) handle.
*/
TSCAPI TSCError TSC_OpenBookmarkFolder(HBookmarkFolder hParent, const uuid_t *uuid, HBookmarkFolder *pHResult);

/*! Closes handle of bookmark folder. The handle should be previously opened by \ref TSC_OpenBookmarkFolder.
\param[in] hFolder Handle to folder to close.
\retval TSCE_Success Handle was successfully closed.
\retval TSCE_InvalidHandle Handle already closed or just invalid value.
*/
TSCAPI TSCError TSC_CloseBookmarkFolderHandle(HBookmarkFolder hFolder);

/* Implicitly generates TSCBFP_Uuid property */
TSCAPI TSCError TSC_CreateBookmarkFolder(HBookmarkFolder hParent, const char *newFolderName, unsigned long lang, HBookmarkFolder *);
TSCAPI TSCError TSC_CreateBookmarkFolderW(HBookmarkFolder hParent, const wchar_t *newFolderName, HBookmarkFolder *);

TSCAPI TSCError TSC_RemoveBookmarkFolder(HBookmarkFolder hParent, const uuid_t *folderUuid);

TSCAPI TSCError TSC_EnumerateFolder(HBookmarkFolder hFolder, TSFOLDERENUMPROC, void *);

/*\{*/
/*!\ingroup APIBookmarkFolderProps */
/* Special case for often used property */
TSCAPI TSCError TSC_GetBookmarkFolderUuid(HBookmarkFolder hFolder, uuid_t *pUuid);

/* Query particular property traits */
TSCAPI TSCError TSC_GetBookmarkFolderPropertyTraits(TSCBookmarkFolderPropertyId, TSPropertyTraits *pTraits);
/* Query set of particular property traits */
TSCAPI TSCError TSC_GetBookmarkFolderPropertiesTraits(const TSCBookmarkFolderPropertyId *pPropertyIds, unsigned itemCount, TSBookmarkFolderIdentifiedPropTraits *pTraits);

/*! Count of all properties used by bookmark folder.
\return Number of properties which can occur in bookmark folder instance. No error possible.
*/
TSCAPI unsigned TSC_GetBookmarkFolderPropertyTraitCount();

/*! Extract complete list of bookmark folder properties traits.
\param[in,out] pTraits array where input/output properties traits are allocated. The array doesn't need of particular initialization.
\param[in] itemCount Size of traits array in items (nor in bytes!).
\param[out] pCount Pointer to receive number of really used items int *pTraits area.
\return TSCE_Success on success or other TSCError code when failed.
*/
TSCAPI TSCError TSC_GetBookmarkFolderAllPropertiesTraits(TSBookmarkFolderIdentifiedPropTraits *pTraits, unsigned itemCount, unsigned *pCount);

TSCAPI TSCError TSC_GetBookmarkFolderProperty(HBookmarkFolder handle, TSCBookmarkFolderPropertyId id, TSPropertyValue *pValue);
TSCAPI TSCError TSC_GetBookmarkFolderProperties(HBookmarkFolder hBookmarkFolder, const TSCBookmarkFolderPropertyId *pIds, unsigned count, TSPropertyValue *pValue);
TSCAPI TSCError TSC_GetBookmarkFolderPropertyEx(HBookmarkFolder hBookmarkFolder, TSBookmarkFolderIdentifiedProp *pValue);
TSCAPI TSCError TSC_GetBookmarkFolderPropertiesEx(HBookmarkFolder hBookmarkFolder, TSBookmarkFolderIdentifiedProp *pValue, unsigned count);

TSCAPI TSCError TSC_SetBookmarkFolderProperty(HBookmarkFolder handle, TSCBookmarkFolderPropertyId id, TSPropertyValue *pValue);
TSCAPI TSCError TSC_SetBookmarkFolderProperties(HBookmarkFolder hBookmarkFolder, const TSCBookmarkFolderPropertyId *pIds, unsigned count, TSPropertyValue *pValue);
TSCAPI TSCError TSC_SetBookmarkFolderPropertyEx(HBookmarkFolder hBookmarkFolder, const TSBookmarkFolderIdentifiedProp *pValue);
TSCAPI TSCError TSC_SetBookmarkFolderPropertiesEx(HBookmarkFolder hBookmarkFolder, TSBookmarkFolderIdentifiedProp *pValue, unsigned count);

/*\}*/

/*\}*/

/*
Bookmarks
*/

TSCAPI TSCError TSC_OpenBookmarkByUuid(const uuid_t *BookmarkUuid, HBookmark *);
TSCAPI TSCError TSC_OpenBookmark(HBookmarkFolder hParent, const uuid_t *BookmarkUuid, HBookmark *);
TSCAPI TSCError TSC_CloseBookmark(HBookmark);
TSCAPI TSCError TSC_CreateBookmark(HBookmarkFolder hParent, const char *newFolderName, unsigned long lang, HBookmark *);
TSCAPI TSCError TSC_CreateBookmarkW(HBookmarkFolder hParent, const wchar_t *newFolderName, HBookmark *);
TSCAPI TSCError TSC_RemoveBookmarkByHandle(HBookmark); // Implicitly closes handle
TSCAPI TSCError TSC_RemoveBookmark(HBookmarkFolder hParent, const uuid_t *pBookmarkUuid);
TSCAPI TSCError TSC_GetBookmarkUuid(HBookmark hBookmark, uuid_t *pUuid);

/* Query particular property traits */
TSCAPI TSCError TSC_GetBookmarkPropertyTraits(TSCBookmarkPropertyId, TSPropertyTraits *pTraits);
/* Query set of particular property traits */
TSCAPI TSCError TSC_GetBookmarkPropertiesTraits(const TSCBookmarkPropertyId *pPropertyIds, unsigned itemCount, TSBookmarkIdentifiedPropTraits *pTraits);
/* Entire number of available properties for bookmark folder type */
TSCAPI unsigned TSC_GetBookmarkPropertyTraitCount();
/* Query for all available property traits */
TSCAPI TSCError TSC_GetBookmarkAllPropertiesTraits(TSBookmarkIdentifiedPropTraits *pTraits, unsigned itemCount, unsigned *pCount);

TSCAPI TSCError TSC_GetBookmarkProperty(HBookmark handle, TSCBookmarkPropertyId id, TSPropertyValue *pValue);
TSCAPI TSCError TSC_GetBookmarkProperties(HBookmark hBookmark, const TSCBookmarkPropertyId *pIds, unsigned count, TSPropertyValue *pValue);
TSCAPI TSCError TSC_GetBookmarkPropertyEx(HBookmark hBookmark, TSBookmarkIdentifiedProp *pValue);
TSCAPI TSCError TSC_GetBookmarkPropertiesEx(HBookmark hBookmark, TSBookmarkIdentifiedProp *pValue, unsigned count);

TSCAPI TSCError TSC_SetBookmarkProperty(HBookmark handle, TSCBookmarkPropertyId id, TSPropertyValue *pValue);
TSCAPI TSCError TSC_SetBookmarkProperties(HBookmark hBookmark, const TSCBookmarkPropertyId *pIds, unsigned count, TSPropertyValue *pValue);
TSCAPI TSCError TSC_SetBookmarkPropertyEx(HBookmark hBookmark, const TSBookmarkIdentifiedProp *pValue);
TSCAPI TSCError TSC_SetBookmarkPropertiesEx(HBookmark hBookmark, TSBookmarkIdentifiedProp *pValue, unsigned count);

/*\}*/

/*
Client launch
*/

/*! Start TeamSpeak client, implicitly starts communications. */
TSCAPI TSCError TSC_StartTSClient();
TSCAPI TSCError TSC_QueryTSClientStatus(TSCClientStatus *);

TSCAPI TSCError TSC_QueryTSClientCommunicationStatus(TSCClientCommunicationStatus *);
TSCAPI TSCError TSC_ConnectToTSClient();
TSCAPI TSCError TSC_DisconnectTSClient();

/*! Check that there is enough thread resources to allocate error object.
\retval 0 There is no ability to allocate resources for last error tracking.
\retval 1 Last error object allocated.
*/
TSCAPI int TSC_LastTSClientErrorAvailable();

/*! Returns last error reported by TeamSpeak client.
\retval TSC_LAST_TSCLIENT_ERROR_NOT_AVAILABLE Last error instance not present.
\retval 0..TSC_LAST_TSCLIENT_ERROR_NOT_AVAILABLE-1 Real last error. */
TSCAPI unsigned long TSC_GetLastTSClientError();

/*! Returns text message coresponding to error of TeamSpeak client.
\retval 0 Last error object is not allocated.
\retval !=0 Error text in UTF-8 encoding. */
TSCAPI const char* TSC_GetLastTSClientErrorText();

/*
Identities
*/

TSCAPI TSCError TSC_GetIdentityPropertyTraits(TSCIdentityPropertyId, TSPropertyTraits *pValue);
TSCAPI TSCError TSC_GetIdentityPropertiesTraits(const TSCIdentityPropertyId *pPropertyIds, unsigned itemCount, TSIdentityIdentifiedPropTraits *pTraits);
unsigned TSCAPI TSC_GetIdentityPropertyTraitCount();
TSCAPI TSCError TSC_GetIdentityAllPropertiesTraits(TSIdentityIdentifiedPropTraits *pTraits, unsigned itemCount, unsigned *pCount);

TSCAPI TSCError TSC_GetIdentityProperty(HIdentity handle, TSCIdentityPropertyId, TSPropertyValue *pValue);
TSCAPI TSCError TSC_GetIdentityProperties(HIdentity handle, const TSCIdentityPropertyId *pIds, unsigned count, TSIdentityIdentifiedProp **ppValue);
TSCAPI TSCError TSC_GetIdentityPropertyEx(HIdentity handle, TSIdentityIdentifiedProp *pValue);
TSCAPI TSCError TSC_GetIdentityPropertiesEx(HIdentity handle, TSIdentityIdentifiedProp *pValue, unsigned count);

TSCAPI TSCError TSC_GetIdentityCount(unsigned long *pCount);
TSCAPI TSCError TSC_GetAllKnownIdentities(HIdentity *pIdentites, unsigned long count, unsigned long *pCountUsed);
TSCAPI TSCError TSC_GetIdentityByName(const char *pName, HIdentity *pHandle);

/*
Server
*/
TSCAPI TSCError TSC_GetVirtualServerPropertyTraits(TSCVirtualServerPropertyId, TSPropertyTraits *pValue);
TSCAPI TSCError TSC_GetVirtualServerPropertiesTraits(const TSCVirtualServerPropertyId *pPropertyIds, unsigned itemCount, TSVirtualServerIdentifiedPropTraits *pTraits);
TSCAPI unsigned TSC_GetVirtualServerPropertyTraitCount();
TSCAPI TSCError TSC_GetVirtualServerAllPropertiesTraits(TSVirtualServerIdentifiedPropTraits *pTraits, unsigned itemCount, unsigned *pCount);

TSCAPI TSCError TSC_GetVirtualServerProperty(HVirtualServer handle, TSCVirtualServerPropertyId, TSPropertyValue *pValue);
TSCAPI TSCError TSC_GetVirtualServerProperties(HVirtualServer handle, const TSCVirtualServerPropertyId *pIds, unsigned count, TSVirtualServerIdentifiedProp **ppValue);
TSCAPI TSCError TSC_GetVirtualServerPropertyEx(HVirtualServer handle, TSVirtualServerIdentifiedProp *pValue);
TSCAPI TSCError TSC_GetVirtualServerPropertiesEx(HVirtualServer handle, TSVirtualServerIdentifiedProp *pValue, unsigned count);

TSCAPI TSCError TSC_GetVirtualServerCount(unsigned *pCount);
TSCAPI TSCError TSC_GetVirtualServerList(HVirtualServer *pHandles, unsigned count, unsigned *pCount);
TSCAPI TSCError TSC_GetCurrentVirtualServer(HVirtualServer *pHandle);
TSCAPI TSCError TSC_SpawnNewVirtualServer(int port, HVirtualServer *pHandle);
TSCAPI TSCError TSC_DestroyVirtualServer(HVirtualServer hServer);
TSCAPI TSCError TSC_RequestVirtualServerProperties(HVirtualServer hServer);

/* Map Handle <-> Id */

/*! Returns handle for the specified server identifier.
\retval 0 Unable to create handle
\retval !=0 Handle, which could be used in other functions of virtual server
*/
TSCAPI HVirtualServer TSC_QueryVirtualServerHandle(uint64 serverID, TSCError *pError);

/*! Returns identifier of someone server which has handle.
\retval 0 The handle could not be resolved to server ID.
\retval !=0 Identifier of server identified by the handle.
*/
TSCAPI uint64 TSC_QueryVirtualServerID(HVirtualServer, TSCError *pError);

TSCAPI TSCError TSC_StartConnection(HVirtualServer, const char* identity,
									const char* ip, unsigned int port,
									const char* nickname,
									const char** defaultChannelArray,
									const char* defaultChannelPassword,
									const char* serverPassword);
TSCAPI TSCError TSC_StopConnection(HVirtualServer, const char* quitMessage);
TSCAPI TSCError TSC_GetClientHandle(HVirtualServer, HClient *phClient);

/*
Connection
*/

TSCAPI TSCError TSC_GetConnectionPropertyTraits(TSCConnectionPropertyId, TSPropertyTraits *pValue);
TSCAPI TSCError TSC_GetConnectionPropertiesTraits(const TSCConnectionPropertyId *pPropertyIds, unsigned itemCount, TSConnectionIdentifiedPropTraits *pTraits);
TSCAPI unsigned TSC_GetConnectionPropertyTraitCount();
TSCAPI TSCError TSC_GetConnectionAllPropertiesTraits(TSConnectionIdentifiedPropTraits *pTraits, unsigned itemCount, unsigned *pCount);

TSCAPI TSCError TSC_GetConnectionProperty(HClient handle, TSCConnectionPropertyId, TSPropertyValue *pValue);
TSCAPI TSCError TSC_GetConnectionProperties(HClient handle, const TSCConnectionPropertyId *pIds, unsigned count, TSConnectionIdentifiedProp **ppValue);
TSCAPI TSCError TSC_GetConnectionPropertyEx(HClient handle, TSConnectionIdentifiedProp *pValue);
TSCAPI TSCError TSC_GetConnectionPropertiesEx(HClient handle, TSConnectionIdentifiedProp *pValue, unsigned count);

TSCAPI TSCError TSC_CleanupConnectionInfo(HClient handle);

/*
Client properties
*/

TSCAPI TSCError TSC_GetClientSelfPropertyTraits(TSCClientPropertyId, TSPropertyTraits *pValue);
TSCAPI TSCError TSC_GetClientSelfPropertiesTraits(const TSCClientPropertyId *pPropertyIds, unsigned itemCount, TSClientSelfIdentifiedPropTraits *pTraits);
TSCAPI unsigned TSC_GetClientSelfPropertyTraitCount();
TSCAPI TSCError TSC_GetClientSelfAllPropertiesTraits(TSClientSelfIdentifiedPropTraits *pTraits, unsigned itemCount, unsigned *pCount);

TSCAPI TSCError TSC_GetClientSelfProperty(HVirtualServer handle, TSCClientPropertyId, TSPropertyValue *pValue);
TSCAPI TSCError TSC_GetClientSelfProperties(HVirtualServer handle, const TSCClientPropertyId *pIds, unsigned count, TSClientSelfIdentifiedProp **ppValue);
TSCAPI TSCError TSC_GetClientSelfPropertyEx(HVirtualServer handle, TSClientSelfIdentifiedProp *pValue);
TSCAPI TSCError TSC_GetClientSelfPropertiesEx(HVirtualServer handle, TSClientSelfIdentifiedProp *pValue, unsigned count);

TSCAPI TSCError TSC_SetClientSelfProperty(HVirtualServer handle, TSCClientPropertyId, const TSPropertyValue *pValue);
TSCAPI TSCError TSC_SetClientSelfPropertyEx(HVirtualServer handle, const TSClientSelfIdentifiedProp *pValue);
TSCAPI TSCError TSC_SetClientSelfProperties(HVirtualServer handle, const TSCClientPropertyId *pIds, unsigned count, const TSPropertyValue *pValue);
TSCAPI TSCError TSC_SetClientSelfPropertiesEx(HVirtualServer handle, const TSClientSelfIdentifiedProp *pValues, unsigned count);
TSCAPI TSCError TSC_FlushClientSelfUpdates(HVirtualServer handle);

TSCAPI TSCError TSC_GetClientPropertyTraits(TSCClientPropertyId, TSPropertyTraits *pValue);
TSCAPI TSCError TSC_GetClientPropertiesTraits(const TSCClientPropertyId *pPropertyIds, unsigned itemCount, TSClientIdentifiedPropTraits *pTraits);
TSCAPI unsigned TSC_GetClientPropertyTraitCount();
TSCAPI TSCError TSC_GetClientAllPropertiesTraits(TSClientIdentifiedPropTraits *pTraits, unsigned itemCount, unsigned *pCount);

TSCAPI TSCError TSC_GetClientProperty(HClient handle, TSCClientPropertyId, TSPropertyValue *pValue);
TSCAPI TSCError TSC_GetClientProperties(HClient handle, const TSCClientPropertyId *pIds, unsigned count, TSClientIdentifiedProp **ppValue);
TSCAPI TSCError TSC_GetClientPropertyEx(HClient handle, TSClientIdentifiedProp *pValue);
TSCAPI TSCError TSC_GetClientPropertiesEx(HClient handle, TSClientIdentifiedProp *pValue, unsigned count);

TSCAPI HClient TSC_QueryClientHandle(HVirtualServer, anyID, TSCError *);
TSCAPI anyID TSC_QueryClientID(HClient, HVirtualServer *, TSCError *);

/*
Channels
*/
TSCAPI TSCError TSC_GetChannelPropertyTraits(TSCChannelPropertyId, TSPropertyTraits *pValue);
TSCAPI TSCError TSC_GetChannelPropertiesTraits(const TSCChannelPropertyId *pPropertyIds, unsigned itemCount, TSChannelIdentifiedPropTraits *pTraits);
TSCAPI unsigned TSC_GetChannelPropertyTraitCount();
TSCAPI TSCError TSC_GetChannelAllPropertiesTraits(TSChannelIdentifiedPropTraits *pTraits, unsigned itemCount, unsigned *pCount);

TSCAPI TSCError TSC_GetChannelProperty(HChannel handle, TSCChannelPropertyId, TSPropertyValue *pValue);
TSCAPI TSCError TSC_GetChannelProperties(HChannel handle, const TSCChannelPropertyId *pIds, unsigned count, TSChannelIdentifiedProp **ppValue);
TSCAPI TSCError TSC_GetChannelPropertyEx(HChannel handle, TSChannelIdentifiedProp *pValue);
TSCAPI TSCError TSC_GetChannelPropertiesEx(HChannel handle, TSChannelIdentifiedProp *pValue, unsigned count);

TSCAPI TSCError TSC_SetChannelProperty(HChannel handle, TSCChannelPropertyId, const TSPropertyValue *pValue);
TSCAPI TSCError TSC_SetChannelPropertyEx(HChannel hChannel, const TSChannelIdentifiedProp *pValue);
TSCAPI TSCError TSC_SetChannelProperties(HChannel handle, const TSCChannelPropertyId *pIds, unsigned count, const TSPropertyValue *pValue);
TSCAPI TSCError TSC_SetChannelPropertiesEx(HChannel handle, const TSChannelIdentifiedProp *pValues, unsigned count);
TSCAPI TSCError TSC_FlushChannelUpdates(HChannel handle);

TSCAPI TSCError TSC_GetSeverChannelList(HVirtualServer hServer, HChannel *pHandles, unsigned long count, unsigned long *pCount);
TSCAPI TSCError TSC_GetChannelClientList(HChannel hChannel, HClient *pHandles, unsigned long count, unsigned long *pCount);

TSCAPI HChannel TSC_QueryChannelHandle(HVirtualServer, uint64, TSCError *);
TSCAPI uint64 TSC_QueryChannelID(HChannel, HVirtualServer *, TSCError *);

/*
Connection library properties
*/

TSCAPI TSCError TSC_GetConnectionLibraryPropertyTraits(TSCConnectionLibraryPropertyId, TSPropertyTraits *pTraits);
/* Query set of particular property traits */
TSCAPI TSCError TSC_GetConnectionLibraryPropertiesTraits(const TSCConnectionLibraryPropertyId *pPropertyIds, unsigned itemCount, TSConnectionLibraryIdentifiedPropTraits *pTraits);
/* Entire number of available properties for bookmark folder type */
TSCAPI unsigned TSC_GetConnectionLibraryPropertyTraitCount();
/* Query for all available property traits */
TSCAPI TSCError TSC_GetConnectionLibraryAllPropertiesTraits(TSConnectionLibraryIdentifiedPropTraits *pTraits, unsigned itemCount, unsigned *pCount);

TSCAPI TSCError TSC_GetConnectionLibraryProperty(TSCConnectionLibraryPropertyId, TSPropertyValue *ppValue);
TSCAPI TSCError TSC_GetConnectionLibraryProperties(const TSCConnectionLibraryPropertyId *pIds, unsigned count, TSPropertyValue *pValue);
TSCAPI TSCError TSC_GetConnectionLibraryPropertyEx(TSConnectionLibraryIdentifiedProp *pValue);
TSCAPI TSCError TSC_GetConnectionLibraryPropertiesEx(TSConnectionLibraryIdentifiedProp *pValue, unsigned count);

/*! Prints message.
\param[in] pValue String or WString-type value.
*/
TSCAPI TSCError TSC_PrintMessageToCurrentTab(const TSPropertyValue *pValue);
TSCAPI TSCError TSC_PrintAStringToCurrentTab(const char *pValue, unsigned long lang);
TSCAPI TSCError TSC_PrintWStringToCurrentTab(const wchar_t *pValue);

TSCAPI TSCError TSC_InstallPluginCallback(TSPLUGINCALLBACK, void *, TSPLUGINCALLBACKHANDLE *pHandle);
TSCAPI TSCError TSC_InstallPluginCallbackFiltered(TSPLUGINCALLBACK, void *, TSPLUGINCALLBACKHANDLE *pHandle,
											  const TSCPluginMessage *pEventsAdd, unsigned long countAdd,
											  const TSCPluginMessage *pEventsRemove, unsigned long countRemove);
TSCAPI TSCError TSC_RemovePluginCallback(TSPLUGINCALLBACKHANDLE);

/*! Modify set of events distributed via particular callback.

\param[in] hCallback Handle of callback being modified.

\param[in] pEventsAdd Pointer to array of \ref TSCPluginMessage constants identifying events which have
to be propagated via the callback. Content of the array is used in dependency on value of \ref countAdd 
parameter. Note that events listed in this array are merged with existing ones. TSCPM_NONE_EVENT is valid
constant for the array but just has no meaning. The parameter could be NULL if \ref countAdd is zero or
\ref TSC_USE_ALL_KNOWN value.

\param[in] Size of \ref pEventsAdd array in items (nor in bytes!). Following values for the parameter are valid:
\li \ref TSC_ZERO_TERMINATED the array is terminated with \ref TSCPM_NULL_EVENT constant (or in other words, its content analyzed till
the \ref TSCPM_NULL_EVENT met.
\li 0 When The array is not used, therefore \ref pEventsAdd could have value of NULL.
\li TSC_USE_ALL_KNOWN All known events will be propagated through the callback.
\ref pEventsAdd is not used therefore could has value of NULL.
\li Range of [1..TSC_USE_ALL_KNOWN-1]. Denotes number of used values.

\param[in] pEventsRemove Pointer to array of \ref TSCPluginMessage constants identifying events which
have to be excluded from set of events propagated via this callback. Other rules are the
same as for \ref pEventsAdd parameter.

\param[in] countRemove Size of \ref pEventsRemove array in items. Other rules are the
same as for \ref countAdd parameter.

\retval TSCE_Success Everything good.
\retval TSCE_InvalidData \ref pEventsAdd or \ref pEventsRemove contains invalid constant, which is not listed
in \ref TSCPluginMessage enumeration.
\retval TSCE_InvalidHandle hCallback is invalid handle.
\retval TSCE_InvalidParameter Someone pointer to array of constants is NULL while appropriate 'count'
denotes someone range.
*/
TSCAPI TSCError TSC_ChangePluginCallbackFilter(TSPLUGINCALLBACKHANDLE hCallback,
											const TSCPluginMessage *pEventsAdd, unsigned long countAdd,
											const TSCPluginMessage *pEventsRemove, unsigned long countRemove);
/*! Add/remove single event to/from set of events propagated via particular callback. */
TSCAPI TSCError TSC_ChangePluginCallbackEvent(TSPLUGINCALLBACKHANDLE hCallback, TSCPluginMessage eventAdd, TSCPluginMessage eventRemove);
TSCAPI TSCError TSC_GetPluginCallbackEvents(TSPLUGINCALLBACKHANDLE hCallback, TSCPluginMessage *pEvents, unsigned long eventCount, unsigned long *pRequiredCount);

#ifdef __cplusplus
} /* extern "C" */
#endif
