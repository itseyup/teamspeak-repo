#pragma once

#include "connect_teamspeak_definitions.h"

/*
Notifications
*/

typedef struct onConnectStatusChangeEvent_
{
	uint64 serverConnectionHandlerID;
	int newStatus;
	unsigned int errorNumber;
} onConnectStatusChangeEvent;

typedef struct onNewChannelEvent_
{
	uint64 serverConnectionHandlerID;
	uint64 channelID;
	uint64 channelParentID;
} onNewChannelEvent;

typedef struct onNewChannelCreatedEvent_
{
	uint64 serverConnectionHandlerID;
	uint64 channelID;
	uint64 channelParentID;
	anyID invokerID;
	const char* invokerName;
	const char* invokerUniqueIdentifier;
} onNewChannelCreatedEvent;

typedef struct onDelChannelEvent_
{
	uint64 serverConnectionHandlerID;
	uint64 channelID;
	anyID invokerID;
	const char* invokerName;
	const char* invokerUniqueIdentifier;
} onDelChannelEvent;

typedef struct onChannelMoveEvent_
{
	uint64 serverConnectionHandlerID;
	uint64 channelID;
	uint64 newChannelParentID;
	anyID invokerID;
	const char* invokerName;
	const char* invokerUniqueIdentifier;
} onChannelMoveEvent;

typedef struct onUpdateChannelEvent_
{
	uint64 serverConnectionHandlerID;
	uint64 channelID;
} onUpdateChannelEvent;

typedef struct onUpdateChannelEditedEvent_
{
	uint64 serverConnectionHandlerID;
	uint64 channelID;
	anyID invokerID;
	const char* invokerName;
	const char* invokerUniqueIdentifier;
} onUpdateChannelEditedEvent;

typedef struct onUpdateClientEvent_
{
	uint64 serverConnectionHandlerID;
	anyID clientID;
} onUpdateClientEvent;

typedef struct onClientMoveEvent_
{
	uint64 serverConnectionHandlerID;
	anyID clientID;
	uint64 oldChannelID;
	uint64 newChannelID;
	int visibility;
	const char* moveMessage;
} onClientMoveEvent;

typedef struct onClientMoveSubscriptionEvent_
{
	uint64 serverConnectionHandlerID;
	anyID clientID;
	uint64 oldChannelID;
	uint64 newChannelID;
	int visibility;
} onClientMoveSubscriptionEvent;

typedef struct onClientMoveTimeoutEvent_
{
	uint64 serverConnectionHandlerID;
	anyID clientID;
	uint64 oldChannelID;
	uint64 newChannelID;
	int visibility;
	const char* timeoutMessage;
} onClientMoveTimeoutEvent;

typedef struct onClientMoveMovedEvent_
{
	uint64 serverConnectionHandlerID;
	anyID clientID;
	uint64 oldChannelID;
	uint64 newChannelID;
	int visibility;
	anyID moverID;
	const char* moverName;
	const char* moverUniqueIdentifier;
	const char* moveMessage;
} onClientMoveMovedEvent;

typedef struct onClientKickFromChannelEvent_
{
	uint64 serverConnectionHandlerID;
	anyID clientID;
	uint64 oldChannelID;
	uint64 newChannelID;
	int visibility;
	anyID kickerID;
	const char* kickerName;
	const char* kickerUniqueIdentifier;
	const char* kickMessage;
} onClientKickFromChannelEvent;

typedef struct onClientKickFromServerEvent_
{
	uint64 serverConnectionHandlerID;
	anyID clientID;
	uint64 oldChannelID;
	uint64 newChannelID;
	int visibility;
	anyID kickerID;
	const char* kickerName;
	const char* kickerUniqueIdentifier;
	const char* kickMessage;
} onClientKickFromServerEvent;

typedef struct onServerEditedEvent_
{
	uint64 serverConnectionHandlerID;
	anyID editerID;
	const char* editerName;
	const char* editerUniqueIdentifier;
} onServerEditedEvent;

typedef struct onServerUpdatedEvent_
{
	uint64 serverConnectionHandlerID;
} onServerUpdatedEvent;

typedef struct onServerErrorEvent_
{
	uint64 serverConnectionHandlerID;
	const char* errorMessage;
	unsigned int error;
	const char* returnCode;
	const char* extraMessage;
} onServerErrorEvent;

typedef struct onServerStopEvent_
{
	uint64 serverConnectionHandlerID;
	const char* shutdownMessage;
} onServerStopEvent;

typedef struct onTextMessageEvent_
{
	uint64 serverConnectionHandlerID;
	anyID targetMode;
	anyID toID;
	anyID fromID;
	const char* fromName;
	const char* fromUniqueIdentifier;
	const char* message;
	int ffIgnored;
} onTextMessageEvent;

typedef struct onTalkStatusChangeEvent_
{
	uint64 serverConnectionHandlerID;
	int status;
	anyID clientID;
} onTalkStatusChangeEvent;

typedef struct onConnectionInfoEvent_
{
	uint64 serverConnectionHandlerID;
	anyID clientID;
} onConnectionInfoEvent;

typedef struct onServerConnectionInfoEvent_
{
	uint64 serverConnectionHandlerID;
} onServerConnectionInfoEvent;

typedef struct onChannelSubscribeEvent_
{
	uint64 serverConnectionHandlerID;
	uint64 channelID;
} onChannelSubscribeEvent;

typedef struct onChannelSubscribeFinishedEvent_
{
	uint64 serverConnectionHandlerID;
} onChannelSubscribeFinishedEvent;

typedef struct onChannelUnsubscribeEvent_
{
	uint64 serverConnectionHandlerID;
	uint64 channelID;
} onChannelUnsubscribeEvent;

typedef struct onChannelUnsubscribeFinishedEvent_
{
	uint64 serverConnectionHandlerID;
} onChannelUnsubscribeFinishedEvent;

typedef struct onChannelDescriptionUpdateEvent_
{
	uint64 serverConnectionHandlerID;
	uint64 channelID;
} onChannelDescriptionUpdateEvent;

typedef struct onChannelPasswordChangedEvent_
{
	uint64 serverConnectionHandlerID;
	uint64 channelID;
} onChannelPasswordChangedEvent;

typedef struct onPlaybackShutdownCompleteEvent_
{
	uint64 serverConnectionHandlerID;
} onPlaybackShutdownCompleteEvent;

typedef struct onUserLoggingMessageEvent_
{
	const char* logMessage;
	int logLevel;
	const char* logChannel;
	uint64 logID;
	const char* logTime;
	const char* completeLogString;
} onUserLoggingMessageEvent;

typedef struct onVoiceRecordDataEvent_
{
	const float* data;
	unsigned int dataSize;
} onVoiceRecordDataEvent;

typedef struct onClientBanFromServerEvent_
{
	uint64 serverConnectionHandlerID;
	anyID clientID;
	uint64 oldChannelID;
	uint64 newChannelID;
	int visibility;
	anyID kickerID;
	const char* kickerName;
	const char* kickerUniqueIdentifier;
	uint64 time;
	const char* kickMessage;
} onClientBanFromServerEvent;

typedef struct onClientPokeEvent_
{
	uint64 serverConnectionHandlerID;
	anyID fromClientID;
	const char* pokerName;
	const char* pokerUniqueIdentity;
	const char* message;
	int ffIgnored;
} onClientPokeEvent;

typedef struct onClientSelfVariableUpdateEvent_
{
	uint64 serverConnectionHandlerID;
	int flag;
	const char* oldValue;
	const char* newValue;
} onClientSelfVariableUpdateEvent;

typedef struct onFileListEvent_
{
	uint64 serverConnectionHandlerID;
	uint64 channelID;
	const char* path;
	const char* name;
	uint64 size;
	uint64 datetime;
	int type;
} onFileListEvent;

typedef struct onFileListFinishedEvent_
{
	uint64 serverConnectionHandlerID;
	uint64 channelID;
	const char* path;
} onFileListFinishedEvent;

typedef struct onFileInfoEvent_
{
	uint64 serverConnectionHandlerID;
	uint64 channelID;
	const char* name;
	uint64 size;
	uint64 datetime;
} onFileInfoEvent;

typedef struct onServerGroupListEvent_
{
	uint64 serverConnectionHandlerID;
	uint64 serverGroupID;
	const char* name;
	int type;
	int iconID;
	int saveDB;
} onServerGroupListEvent;

typedef struct onServerGroupListFinishedEvent_
{
	uint64 serverConnectionHandlerID;
} onServerGroupListFinishedEvent;

typedef struct onServerGroupByClientIDEvent_
{
	uint64 serverConnectionHandlerID;
	const char* name;
	uint64 serverGroupList;
	uint64 clientDatabaseID;
} onServerGroupByClientIDEvent;

typedef struct onServerGroupPermListEvent_
{
	uint64 serverConnectionHandlerID;
	uint64 serverGroupID;
	anyID permissionID;
	int permissionValue;
	int permissionNegated;
	int permissionSkip;
} onServerGroupPermListEvent;

typedef struct onServerGroupPermListFinishedEvent_
{
	uint64 serverConnectionHandlerID;
	uint64 serverGroupID;
} onServerGroupPermListFinishedEvent;

typedef struct onServerGroupClientListEvent_
{
	uint64 serverConnectionHandlerID;
	uint64 serverGroupID;
	uint64 clientDatabaseID;
	const char* clientNameIdentifier;
	const char* clientUniqueID;
} onServerGroupClientListEvent;

typedef struct onChannelGroupListEvent_
{
	uint64 serverConnectionHandlerID;
	uint64 channelGroupID;
	const char* name;
	int type;
	int iconID;
	int saveDB;
} onChannelGroupListEvent;

typedef struct onChannelGroupListFinishedEvent_
{
	uint64 serverConnectionHandlerID;
} onChannelGroupListFinishedEvent;

typedef struct onChannelGroupPermListEvent_
{
	uint64 serverConnectionHandlerID;
	uint64 channelGroupID;
	anyID permissionID;
	int permissionValue;
	int permissionNegated;
	int permissionSkip;
} onChannelGroupPermListEvent;

typedef struct onChannelGroupPermListFinishedEvent_
{
	uint64 serverConnectionHandlerID;
	uint64 channelGroupID;
} onChannelGroupPermListFinishedEvent;

typedef struct onChannelPermListEvent_
{
	uint64 serverConnectionHandlerID;
	uint64 channelID;
	anyID permissionID;
	int permissionValue;
	int permissionNegated;
	int permissionSkip;
} onChannelPermListEvent;

typedef struct onChannelPermListFinishedEvent_
{
	uint64 serverConnectionHandlerID;
	uint64 channelID;
} onChannelPermListFinishedEvent;

typedef struct onClientPermListEvent_
{
	uint64 serverConnectionHandlerID;
	uint64 clientDatabaseID;
	anyID permissionID;
	int permissionValue;
	int permissionNegated;
	int permissionSkip;
} onClientPermListEvent;

typedef struct onClientPermListFinishedEvent_
{
	uint64 serverConnectionHandlerID;
	uint64 clientDatabaseID;
} onClientPermListFinishedEvent;

typedef struct onChannelClientPermListEvent_
{
	uint64 serverConnectionHandlerID;
	uint64 channelID;
	uint64 clientDatabaseID;
	anyID permissionID;
	int permissionValue;
	int permissionNegated;
	int permissionSkip;
} onChannelClientPermListEvent;

typedef struct onChannelClientPermListFinishedEvent_
{
	uint64 serverConnectionHandlerID;
	uint64 channelID;
	uint64 clientDatabaseID;
} onChannelClientPermListFinishedEvent;

typedef struct onClientChannelGroupChangedEvent_
{
	uint64 serverConnectionHandlerID;
	uint64 channelGroupID;
	uint64 channelID;
	anyID clientID;
	anyID invokerClientID;
	const char* invokerName;
	const char* invokerUniqueIdentity;
} onClientChannelGroupChangedEvent;

typedef struct onServerPermissionErrorEvent_
{
	uint64 serverConnectionHandlerID;
	const char* errorMessage;
	unsigned int error;
	const char* returnCode;
	anyID failedPermissionID;
} onServerPermissionErrorEvent;

typedef struct onPermissionListEvent_
{
	uint64 serverConnectionHandlerID;
	anyID permissionID;
	const char* permissionName;
	const char* permissionDescription;
} onPermissionListEvent;

typedef struct onPermissionListFinishedEvent_
{
	uint64 serverConnectionHandlerID;
} onPermissionListFinishedEvent;

typedef struct onPermissionOverviewEvent_
{
	uint64 serverConnectionHandlerID;
	uint64 clientDatabaseID;
	uint64 channelID;
	int overviewType;
	uint64 overviewID1;
	uint64 overviewID2;
	anyID permissionID;
	int permissionValue;
	int permissionNegated;
	int permissionSkip;
} onPermissionOverviewEvent;

typedef struct onPermissionOverviewFinishedEvent_
{
	uint64 serverConnectionHandlerID;
} onPermissionOverviewFinishedEvent;

typedef struct onServerGroupClientAddedEvent_
{
	uint64 serverConnectionHandlerID;
	anyID clientID;
	const char* clientName;
	const char* clientUniqueIdentity;
	uint64 serverGroupID;
	anyID invokerClientID;
	const char* invokerName;
	const char* invokerUniqueIdentity;
} onServerGroupClientAddedEvent;

typedef struct onServerGroupClientDeletedEvent_
{
	uint64 serverConnectionHandlerID;
	anyID clientID;
	const char* clientName;
	const char* clientUniqueIdentity;
	uint64 serverGroupID;
	anyID invokerClientID;
	const char* invokerName;
	const char* invokerUniqueIdentity;
} onServerGroupClientDeletedEvent;

typedef struct onClientNeededPermissionsEvent_
{
	uint64 serverConnectionHandlerID;
	anyID permissionID;
	int permissionValue;
} onClientNeededPermissionsEvent;

typedef struct onClientNeededPermissionsFinishedEvent_
{
	uint64 serverConnectionHandlerID;
} onClientNeededPermissionsFinishedEvent;

typedef struct onFileTransferStatusEvent_
{
	anyID transferID;
	unsigned int status;
	const char* statusMessage;
	uint64 remotefileSize;
	uint64 serverConnectionHandlerID;
} onFileTransferStatusEvent;

typedef struct onClientChatClosedEvent_
{
	uint64 serverConnectionHandlerID;
	anyID clientID;
} onClientChatClosedEvent;

typedef struct onClientChatComposingEvent_
{
	uint64 serverConnectionHandlerID;
	anyID clientID;
} onClientChatComposingEvent;

typedef struct onServerLogEvent_
{
	uint64 serverConnectionHandlerID;
	const char* logTimestamp;
	const char* logChannel;
	int logLevel;
	const char* logMsg;
} onServerLogEvent;

typedef struct onServerLogFinishedEvent_
{
	uint64 serverConnectionHandlerID;
} onServerLogFinishedEvent;

typedef struct onServerQueryEvent_
{
	uint64 serverConnectionHandlerID;
	const char* result;
} onServerQueryEvent;

typedef struct onMessageListEvent_
{
	uint64 serverConnectionHandlerID;
	uint64 messageID;
	const char* fromClientUniqueIdentity;
	const char* subject;
	uint64 timestamp;
	int flagRead;
} onMessageListEvent;

typedef struct onMessageGetEvent_
{
	uint64 serverConnectionHandlerID;
	uint64 messageID;
	const char* fromClientUniqueIdentity;
	const char* subject;
	const char* message;
	uint64 timestamp;
} onMessageGetEvent;

typedef struct onClientDBIDfromUIDEvent_
{
	uint64 serverConnectionHandlerID;
	const char* uniqueClientIdentifier;
	uint64 clientDatabaseID;
} onClientDBIDfromUIDEvent;

typedef struct onClientNamefromUIDEvent_
{
	uint64 serverConnectionHandlerID;
	const char* uniqueClientIdentifier;
	uint64 clientDatabaseID;
	const char* clientNickName;
} onClientNamefromUIDEvent;

typedef struct onClientNamefromDBIDEvent_
{
	uint64 serverConnectionHandlerID;
	const char* uniqueClientIdentifier;
	uint64 clientDatabaseID;
	const char* clientNickName;
} onClientNamefromDBIDEvent;

typedef struct onComplainListEvent_
{
	uint64 serverConnectionHandlerID;
	uint64 targetClientDatabaseID;
	const char* targetClientNickName;
	uint64 fromClientDatabaseID;
	const char* fromClientNickName;
	const char* complainReason;
	uint64 timestamp;
} onComplainListEvent;

typedef struct onBanListEvent_
{
	uint64 serverConnectionHandlerID;
	uint64 banid;
	const char* ip;
	const char* name;
	const char* uid;
	uint64 creationTime;
	uint64 durationTime;
	const char* invokerName;
	uint64 invokercldbid;
	const char* invokeruid;
	const char* reason;
	int numberOfEnforcements;
} onBanListEvent;

typedef struct onClientServerQueryLoginPasswordEvent_
{
	uint64 serverConnectionHandlerID;
	const char* loginPassword;
} onClientServerQueryLoginPasswordEvent;

typedef struct onPluginCommandEvent_
{
	uint64 serverConnectionHandlerID;
	const char* pluginName;
	const char* pluginCommand;
} onPluginCommandEvent;

typedef enum TSCPluginMessage_
{
	TSCPM_NULL_EVENT								= 0,
	TSCPM_onConnectStatusChangeEvent				= 1,
	TSCPM_onNewChannelEvent							= 2,
	TSCPM_onNewChannelCreatedEvent					= 3,
	TSCPM_onDelChannelEvent							= 4,
	TSCPM_onChannelMoveEvent						= 5,
	TSCPM_onUpdateChannelEvent						= 6,
	TSCPM_onUpdateChannelEditedEvent				= 7,
	TSCPM_onUpdateClientEvent						= 8,
	TSCPM_onClientMoveEvent							= 9,
	TSCPM_onClientMoveSubscriptionEvent				= 10,
	TSCPM_onClientMoveTimeoutEvent					= 11,
	TSCPM_onClientMoveMovedEvent					= 12,
	TSCPM_onClientKickFromChannelEvent				= 13,
	TSCPM_onClientKickFromServerEvent				= 14,
	TSCPM_onServerEditedEvent						= 15,
	TSCPM_onServerUpdatedEvent						= 16,
	TSCPM_onServerErrorEvent						= 17,
	TSCPM_onServerStopEvent							= 18,
	TSCPM_onTextMessageEvent						= 19,
	TSCPM_onTalkStatusChangeEvent					= 20,
	TSCPM_onConnectionInfoEvent						= 21,
	TSCPM_onServerConnectionInfoEvent				= 22,
	TSCPM_onChannelSubscribeEvent					= 23,
	TSCPM_onChannelSubscribeFinishedEvent			= 24,
	TSCPM_onChannelUnsubscribeEvent					= 25,
	TSCPM_onChannelUnsubscribeFinishedEvent			= 26,
	TSCPM_onChannelDescriptionUpdateEvent			= 27,
	TSCPM_onChannelPasswordChangedEvent				= 28,
	TSCPM_onPlaybackShutdownCompleteEvent			= 29,
	TSCPM_onUserLoggingMessageEvent					= 30,
	TSCPM_onVoiceRecordDataEvent					= 31,
	TSCPM_onClientBanFromServerEvent				= 32,
	TSCPM_onClientPokeEvent							= 33,
	TSCPM_onClientSelfVariableUpdateEvent			= 34,
	TSCPM_onFileListEvent							= 35,
	TSCPM_onFileListFinishedEvent					= 36,
	TSCPM_onFileInfoEvent							= 37,
	TSCPM_onServerGroupListEvent					= 38,
	TSCPM_onServerGroupListFinishedEvent			= 39,
	TSCPM_onServerGroupByClientIDEvent				= 40,
	TSCPM_onServerGroupPermListEvent				= 41,
	TSCPM_onServerGroupPermListFinishedEvent		= 42,
	TSCPM_onServerGroupClientListEvent				= 43,
	TSCPM_onChannelGroupListEvent					= 44,
	TSCPM_onChannelGroupListFinishedEvent			= 45,
	TSCPM_onChannelGroupPermListEvent				= 46,
	TSCPM_onChannelGroupPermListFinishedEvent		= 47,
	TSCPM_onChannelPermListEvent					= 48,
	TSCPM_onChannelPermListFinishedEvent			= 49,
	TSCPM_onClientPermListEvent						= 50,
	TSCPM_onClientPermListFinishedEvent				= 51,
	TSCPM_onChannelClientPermListEvent				= 52,
	TSCPM_onChannelClientPermListFinishedEvent		= 53,
	TSCPM_onClientChannelGroupChangedEvent			= 54,
	TSCPM_onServerPermissionErrorEvent				= 55,
	TSCPM_onPermissionListEvent						= 56,
	TSCPM_onPermissionListFinishedEvent				= 57,
	TSCPM_onPermissionOverviewEvent					= 58,
	TSCPM_onPermissionOverviewFinishedEvent			= 59,
	TSCPM_onServerGroupClientAddedEvent				= 60,
	TSCPM_onServerGroupClientDeletedEvent			= 61,
	TSCPM_onClientNeededPermissionsEvent			= 62,
	TSCPM_onClientNeededPermissionsFinishedEvent	= 63,
	TSCPM_onFileTransferStatusEvent					= 64,
	TSCPM_onClientChatClosedEvent					= 65,
	TSCPM_onClientChatComposingEvent				= 66,
	TSCPM_onServerLogEvent							= 67,
	TSCPM_onServerLogFinishedEvent					= 68,
	TSCPM_onServerQueryEvent						= 69,
	TSCPM_onMessageListEvent						= 70,
	TSCPM_onMessageGetEvent							= 71,
	TSCPM_onClientDBIDfromUIDEvent					= 72,
	TSCPM_onClientNamefromUIDEvent					= 73,
	TSCPM_onClientNamefromDBIDEvent					= 74,
	TSCPM_onComplainListEvent						= 75,
	TSCPM_onBanListEvent							= 76,
	TSCPM_onClientServerQueryLoginPasswordEvent		= 77,
	TSCPM_onPluginCommandEvent						= 78,
	TSCPM_EVENT_MAX									= 79 /*! Internal usage only, otherwise - invalid. */
} TSCPluginMessage;

#define TSC_ZERO_TERMINATED (~0UL)
#define TSC_USE_ALL_KNOWN ((~0UL)-1)

typedef void (TSCALLBACK* TSPLUGINCALLBACK)(TSCPluginMessage, const void *, void *, long *);

