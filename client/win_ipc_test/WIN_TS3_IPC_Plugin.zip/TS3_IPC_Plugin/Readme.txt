TeamSpeak 3 IPC Plugin pre-release version
Copyright (c) 2010 TeamSpeak Systems GmbH

This package includes headers, lib and dll files to create an application using
the TeamSpeak 3 IPC plugin to control the TeamSpeak 3 client.
A small sample application is included which demonstrates how to start the
TeamSpeak 3 client and connect to a TeamSpeak 3 server on localhost using the
IPC mechanism.

*** This is a pre-release version and not fully implemented. ***

Requirements:

- TeamSpeak 3 client beta21 or above
- Copy tsconnect_plugin.dll from ts3client_plugin directory to the plugins
  directory of the TeamSpeak 3 installation path.
- Start TeamSpeak 3 client and enable the TSConnect Plugin in the plugins
  dialog.

Notes on the example source code:

- The sample tries to connect on a TeamSpeak 3 server on localhost:9987
  You might want to change the server address for your tests.
- The sample tries to read the Identity "Standard", used for connecting
  to the localhost server. This is from a German TeamSpeak 3 client, with
  the English version the Identity should be named "Default".
- There are currently some issues with the IPC plugin not finding the
  correct configuration paths. You might need to copy the TeamSpeak 3
  client configuration from its directory in APPDATA to a directory
  "config" in the TeamSpeak 3 client installation path.
